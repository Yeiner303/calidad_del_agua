# Progreso por fases

- [x] Fase 1 — Cimientos y modelo reproducido
- [x] Fase 2 — Validación y EDA dinámico
- [x] Fase 3 — API y predicción
- [x] Fase 4 — Reportes PDF, JSON, CSV y XLSX
- [x] Fase 5 — Actualización, comparación y versionamiento
- [x] Fase 6 — 11 archivos de prueba y evidencias por escenario
- [x] Fase 7 — Frontend React, ocho vistas, pruebas y build
- [x] Fase 8 — Integración API validada y artefactos frontend compilados
- [x] Fase 9 — Documentación, documento técnico y ZIP

## Verificación

- Modelo: 17.666 pares; partición temporal de 14.728/2.938; MAE 5,6953, RMSE 9,7417 y R² 0,5893; mejor que persistencia (MAE 5,9802 y RMSE 10,2541).
- Backend: 16 pruebas aprobadas; cobertura combinada de 93 % en validación, pipeline, versionamiento y reportes.
- Frontend: TypeScript, ESLint, 3 pruebas de componentes y build de producción aprobados.
- EDA del CSV completo: 19.160 filas y 11 columnas en 2,8 segundos.
- API: escenarios esperados y obtenidos coinciden en los 11 archivos; se generaron 28 PDFs de reporte y se verificó su apertura y renderizado representativo.
- Instalación limpia: extracción del ZIP, instalación desde `requirements-dev.txt`, 16 pruebas backend aprobadas, `npm ci` y cuatro verificaciones frontend aprobadas.
- Límite del entorno: Uvicorn y Vite iniciaron correctamente, pero las solicitudes del shell a `127.0.0.1` agotaron el tiempo de espera; el flujo API se comprobó con `TestClient`.
