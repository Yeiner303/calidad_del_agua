# Resultados esperados y obtenidos

| Archivo | Esperado | Obtenido | Códigos observados |
|---|---|---|---|
| 01_compatible.csv | compatible | compatible | I_IGNORED_COLUMNS, I_YEAR_THOUSANDS |
| 02_falta_columna_irca.csv | incompatible | incompatible | E_MISSING_COLUMN, I_IGNORED_COLUMNS, I_YEAR_THOUSANDS |
| 03_tipos_incompatibles.csv | incompatible | incompatible | E_TYPE, I_IGNORED_COLUMNS, I_YEAR_THOUSANDS |
| 04_nulos_irca.csv | incompatible | incompatible | E_NULLS, I_IGNORED_COLUMNS, I_YEAR_THOUSANDS |
| 05_categoria_desconocida.csv | compatible_with_warnings | compatible_with_warnings | I_CATEGORY_ALIAS, I_IGNORED_COLUMNS, I_YEAR_THOUSANDS, W_UNKNOWN_CATEGORY, W_UNKNOWN_DEPARTMENT |
| 06_columnas_adicionales.csv | compatible_with_warnings | compatible_with_warnings | I_IGNORED_COLUMNS, I_YEAR_THOUSANDS, W_EXTRA_COLUMNS |
| 07_solo_eda_muestras_laboratorio.csv | incompatible | incompatible | E_MISSING_COLUMN, W_EXTRA_COLUMNS |
| 07b_irca_fuera_de_rango.csv | incompatible | incompatible | E_DOMAIN_RANGE, I_IGNORED_COLUMNS, I_YEAR_THOUSANDS |
| 09_compatible.xlsx | compatible | compatible | I_IGNORED_COLUMNS, I_YEAR_THOUSANDS |
| 08b_reentrenamiento_claves_repetidas.csv | incompatible | incompatible | E_KEY_ALREADY_IN_TRAINING, I_CATEGORY_ALIAS, I_IGNORED_COLUMNS, I_YEAR_THOUSANDS |
| 08_nuevos_datos_etiquetados_2025.csv | candidate | candidate | I_IGNORED_COLUMNS, I_YEAR_THOUSANDS, W_EXTRAPOLATION, W_LEVEL_MISMATCH |
