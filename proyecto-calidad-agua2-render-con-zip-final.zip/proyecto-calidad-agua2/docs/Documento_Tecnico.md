# Documento técnico

Proyecto de análisis automatizado y consumo del modelo predictivo IRCA. Versión de aplicación 1.0.0.

## Arquitectura

La interfaz React y Vite consume una API FastAPI. La API coordina lectura CSV/XLSX, validación desde `schema.json`, EDA, predicción con pipeline persistido, generación de reportes y versionamiento. Los runs conservan el archivo original y resultados para reabrirlos. El registro de modelos se escribe mediante reemplazo atómico.

## Validación y predicción

El esquema concentra nombres, tipos, rangos, nulabilidad, categorías, alias y columnas excluidas del modelo. Las reglas se aplican en el servidor; una sola incompatibilidad bloquea el archivo completo. El EDA sigue disponible si el archivo pudo leerse. La API repite la validación antes de cada inferencia.

El pipeline sklearn contiene un transformador determinista que produce solo `IRCA_t` y `Año_desde_2007`, seguido de regresión lineal ordinaria. Los identificadores son usados para asociar las salidas con filas, nunca entran al modelo. La predicción no ajusta transformadores y se recorta al rango 0-100. Los cuantiles p10 y p90 de residuos del holdout forman un rango de referencia, no una probabilidad ni un intervalo de confianza formal.

## Entrenamiento y comparación

Se forman pares solo cuando la misma clave geográfica tiene años consecutivos t y t+1. Se reservan para prueba los tres años objetivo más recientes. Se informan MAE, RMSE y R² junto con persistencia; el artefacto final se ajusta con todos los pares. Una actualización se valida y analiza antes de integrarse en un dataset candidato. El sistema calcula al menos 30 pares nuevos, entrena una candidata y la compara con el modelo activo. Se usa una prueba ciega común posterior al último año objetivo activo cuando hay suficientes observaciones; de lo contrario se usa el holdout y se muestra la nota de justicia. Promover, descartar y activar una versión anterior requieren justificación.

## Limitaciones conocidas

El modelo global solo usa dos predictores y el dataset suministrado termina en 2024. La extrapolación del término de año puede ser inestable. Las filas agregadas `#TODOS` se conservan junto con las municipales. Los tokens `ND` son datos no disponibles y no se imputan para forzar predicciones. Las categorías observadas y las correlaciones no implican causalidad. Los escenarios 7 y 8 son sintéticos de demostración. El pronóstico no incluye infraestructura, clima, tratamiento ni vigilancia y no sustituye una medición del agua.
