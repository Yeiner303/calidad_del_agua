# Arquitectura

```mermaid
flowchart LR
  U[Usuario] --> UI[React + Vite]
  UI -->|CSV/XLSX| API[FastAPI]
  API --> IO[Lectura segura]
  IO --> VAL[Validación desde schema.json]
  IO --> EDA[EDA dinámico + ChartSpec]
  VAL -->|compatible| PIPE[Pipeline sklearn persistido]
  VAL -->|incompatible| DIAG[Diagnóstico + EDA disponible]
  PIPE --> PRED[Predicciones + rango de referencia]
  EDA --> REP[Módulo de reportes]
  VAL --> REP
  PRED --> REP
  API --> RUNS[Runs y archivos temporales]
  API --> REG[Registro JSON de versiones]
  REG --> ACTIVE[Modelo activo + joblib]
  API -->|datos etiquetados| RETRAIN[Reentrenamiento candidato]
  RETRAIN --> CMP[Comparación común y nota de justicia]
  CMP --> DEC[Promover / descartar / rollback]
  DEC --> REG
  DEC --> ACTIVE
```

El backend verifica compatibilidad por solicitud antes de inferir. Los identificadores acompañan la salida para que el registro pueda reconocerse, pero el transformador del pipeline produce únicamente `IRCA_t` y `Año_desde_2007`. Las reglas de validación viven en `backend/metadata/schema.json`.
