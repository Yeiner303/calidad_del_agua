# Calidad del Agua · IRCA

Aplicativo web para explorar archivos de calidad del agua, revisar su compatibilidad y pronosticar el IRCA del siguiente año. La interfaz y la API son locales; el EDA también funciona en archivos que no son aptos para predicción.

## Requisitos

- Python 3.11 o superior.
- Node.js 20 o superior y npm.
- Windows 10/11 con PowerShell, macOS o Linux.
- Conexión a internet solo durante la instalación de dependencias. Luego la aplicación se ejecuta localmente.

## Instalación y arranque

Abra esta carpeta en Visual Studio Code mediante **File → Open Folder**. Abra una terminal desde **Terminal → New Terminal** y divídala para mantener backend y frontend en terminales distintas.

### Backend

Desde la raíz del proyecto:

```powershell
cd backend
python -m venv .venv
# PowerShell
.\.venv\Scripts\Activate.ps1
# macOS/Linux, en lugar de la línea anterior:
# source .venv/bin/activate
pip install -r requirements-dev.txt
python ../scripts/bootstrap_model.py
uvicorn app.main:app --reload --host 127.0.0.1 --port 8000
```

Si PowerShell bloquea la activación, use `Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass` en esa terminal y repita ` .\.venv\Scripts\Activate.ps1`. No cambia la política permanente del equipo. La API queda en **http://127.0.0.1:8000** y Swagger en **http://127.0.0.1:8000/docs**. Espere el mensaje de Uvicorn `Application startup complete`.

### Frontend

En la otra terminal, desde la raíz:

```powershell
cd frontend
npm ci
npm run dev
```

Vite indicará **http://localhost:5173**. Abra esa dirección en el navegador. La interfaz usa el proxy de Vite para consultar el backend.

### Primera demostración guiada

1. Abra **Archivos de prueba** y ejecute `01_compatible.csv`. Debe resultar compatible y habilitar predicciones.
2. En el resultado, abra EDA y descargue su PDF; vuelva a **Predicciones** para calcular IRCA 2025.
3. Ejecute `02_falta_columna_irca.csv`. Debe resultar incompatible; el botón de predicción queda deshabilitado y el diagnóstico señala `E_MISSING_COLUMN`. Abra el EDA del mismo archivo.
4. Ejecute `03_tipos_incompatibles.csv`, `04_nulos_irca.csv` y `07b_irca_fuera_de_rango.csv` para revisar tipos, faltantes y dominio.
5. Ejecute `05_categoria_desconocida.csv` y `06_columnas_adicionales.csv`. Son compatibles con advertencias.
6. Ejecute `07_solo_eda_muestras_laboratorio.csv`. No se puede predecir; sí se muestran gráficos temporales, estadística numérica, categorías y atípicos.
7. Ejecute `09_compatible.xlsx` para revisar lectura Excel.
8. En **Actualizar modelo**, cargue `08_nuevos_datos_etiquetados_2025.csv`. Revise validación y EDA, entrene la candidata, compare las métricas y decida con una justificación de al menos 10 caracteres. El modelo activo no cambia hasta promover. Para la demo inicial se puede descartar la candidata.
9. `08b_reentrenamiento_claves_repetidas.csv` debe ser rechazado porque repite claves del conjunto activo.

### Contexto territorial de Chocó (2020)

La opción **Contexto 2020** compara el IRCA municipal de SIVICAP con los indicadores PDA 2020 publicados por Aguas del Chocó. El cruce incluye los municipios presentes en ambas fuentes y muestra cobertura del servicio, continuidad, calidad reportada e infraestructura. La ruta de consulta es `GET /api/context/choco-2020`.

El CSV complementario se conserva en `backend/data/contextual/aguas_del_choco_indicadores_pda_2020.csv`; su procedencia y limitaciones están en `backend/data/contextual/fuente_aguas_del_choco.json`. Los datos corresponden al mismo año para evitar comparar periodos distintos. La muestra común es reducida y las etiquetas de calidad pueden diferir entre fuentes; se presenta como contraste descriptivo y no permite afirmar causalidad ni estimar una relación estadística concluyente.

### Comparación de las seis regiones naturales (2018-2021)

La vista **Seis regiones** compara las medianas anuales del IRCA con la cobertura municipal de acueducto del SUI en los cuatro años comunes. El cruce usa año y código DIVIPOLA; faltantes y pares válidos se muestran en la pantalla. Puede elegir Andina, Caribe, Orinoquía, Amazonía o Insular para comparar con Pacífica. La cobertura del servicio no significa potabilidad. Los patrones son descriptivos y no demuestran causas; la asignación operativa por departamento aproxima las regiones naturales. Esta vista no modifica el pronóstico del modelo.

El CSV oficial utilizado está en `backend/data/contextual/sui_cobertura_acueducto_municipal_2018_2021.csv`, con procedencia, servicios anuales y criterios de extracción en `backend/data/contextual/fuente_sui_cobertura_acueducto_2018_2021.json`. Para actualizarlo desde las capas públicas de la SSPD/SIGSUPER, ejecute `python scripts/collect_sui_coverage.py`. El análisis web se sirve en `GET /api/context/regional?comparacion=Andina`; el notebook regional actualizado está en `docs/referencia/Actividad_Calidad_del_Agua_Colombia.ipynb`.

Los archivos 7 y 8 se marcan como sintéticos de demostración en el catálogo. Los archivos 1–6, 7b, 8b y 9 se construyen de forma determinista desde el CSV suministrado.

## Pruebas y calidad

Desde `backend/`, instale dependencias de desarrollo con `pip install -r requirements-dev.txt`, ejecute `python -m pytest --cov=app.validation --cov=app.pipeline --cov=app.versioning --cov=app.reports` y `python -m ruff check --config pyproject.toml app tests ../scripts`. El archivo de desarrollo incluye los requisitos de ejecución.

Desde `frontend/`: `npm ci`, `npm run typecheck`, `npm run lint`, `npm run test` y `npm run build`.

## Estructura

- `backend/app/validation`: reglas leídas de `backend/metadata/schema.json`.
- `backend/app/eda`: inferencia de tipos, estadísticas y ChartSpec.
- `backend/app/pipeline`: pipeline sklearn y protocolo temporal.
- `backend/app/reports`: PDF, CSV, XLSX y JSON.
- `backend/app/versioning`: registro, candidatas, promoción y rollback.
- `frontend/src`: interfaz React, rutas, visualizaciones y cliente API.
- `test_files/`: escenarios para la demostración.
- `docs/referencia/`: notebook y enunciado de referencia.
- `backend/data/contextual/`: CSV nacional SUI de cobertura 2018-2021 y ficha PDA de Choco 2020.
- `backend/models/`: artefacto y metadatos de v1.

## Decisiones y límites

El estimador es una regresión lineal ordinaria con dos predictores: IRCA(t) y año desde 2007. Los pares se crean únicamente entre años consecutivos de una misma clave geográfica. La evaluación reserva los tres años objetivo más recientes, compara contra persistencia y ajusta el artefacto final con todos los pares. El pronóstico se recorta a 0–100.

El nivel de riesgo es una etiqueta derivada determinista, no una probabilidad. El rango mostrado usa cuantiles de residuos del holdout y no es un intervalo de confianza. No hay inferencia causal. El conjunto llega hasta 2024; las series `#TODOS` (agregadas) se mantienen junto con las municipales; `ND` no está disponible y se reporta. La variable de año extrapola fuera del periodo observado. Los escenarios 7 y 8 son sintéticos.

## Solución de problemas

- **`python` no reconocido:** instale Python 3.11+ y active “Add Python to PATH”; en Windows también puede usar `py -3.12` en vez de `python`.
- **Entorno virtual bloqueado en PowerShell:** ejecute `Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass` solo para la sesión actual, luego active el entorno.
- **Puerto 8000 ocupado:** detenga el otro proceso o arranque Uvicorn con `--port 8001`; si cambia el puerto, actualice el proxy en `frontend/vite.config.ts`.
- **Puerto 5173 ocupado:** Vite propondrá otro puerto; mantenga 5173 o actualice CORS en `backend/app/config.py`.
- **Node antiguo:** revise `node --version`; instale Node 20 o superior y abra una terminal nueva.
- **`npm install` falla:** compruebe conexión durante la instalación, ejecute `npm cache verify` y vuelva a instalar.
- **No aparece modelo activo:** desde `backend/`, active el venv y ejecute `python ../scripts/bootstrap_model.py`; luego reinicie Uvicorn.

## API

Swagger documenta operaciones y modelos en `/docs`. Las respuestas de error contienen un mensaje en español y un código de referencia; el detalle técnico se conserva en `backend/logs/app.log`.
