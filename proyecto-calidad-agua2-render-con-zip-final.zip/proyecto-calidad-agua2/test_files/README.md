# Archivos de prueba

Los archivos se generan con `python scripts/generate_test_files.py`; el script usa una semilla fija (42). Los archivos 7 y 8 son sintéticos de demostración y no representan mediciones oficiales.

| Escenario | Archivo | Resultado esperado | Propósito |
|---|---|---|---|
| 1 | 01_compatible.csv | compatible | Predicción desde muestra 2024 |
| 2 | 02_falta_columna_irca.csv | incompatible | Columna obligatoria ausente |
| 3 | 03_tipos_incompatibles.csv | incompatible | IRCA/Año con texto |
| 4 | 04_nulos_irca.csv | incompatible | 8 % de IRCA vacío o ND |
| 5 | 05_categoria_desconocida.csv | compatible_with_warnings | Categoría y departamento no vistos |
| 6 | 06_columnas_adicionales.csv | compatible_with_warnings | Columnas extra ignoradas |
| 7 | 07_solo_eda_muestras_laboratorio.csv | incompatible para predecir | EDA temporal, numérico, categórico, duplicados y atípicos |
| 7b | 07b_irca_fuera_de_rango.csv | incompatible | IRCA fuera de 0–100 |
| 8 | 08_nuevos_datos_etiquetados_2025.csv | candidate | Reentrenamiento demostrativo; datos sintéticos |
| 8b | 08b_reentrenamiento_claves_repetidas.csv | incompatible | Rechazo de claves ya entrenadas |
| 9 | 09_compatible.xlsx | compatible | Lectura de libro Excel |

Desde la interfaz use **Archivos de prueba → Probar con este archivo**. Desde Swagger, use `POST /api/validate`, `POST /api/eda` o `POST /api/predict` y adjunte el archivo. Para actualizar, use `POST /api/model/retrain`; la candidata requiere decisión con justificación.
