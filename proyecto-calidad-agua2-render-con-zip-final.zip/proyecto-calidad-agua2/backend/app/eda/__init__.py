"""Análisis exploratorio dinámico."""
