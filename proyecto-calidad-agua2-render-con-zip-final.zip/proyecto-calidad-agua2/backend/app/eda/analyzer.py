"""EDA dinámico: infiere tipos y calcula estadísticas verificables."""

from __future__ import annotations

import re
import unicodedata
from collections import Counter

import numpy as np
import pandas as pd

from app.config import MAX_EDA_ROWS
from app.core.errors import AppError
from app.core.serialization import json_safe

PLACEHOLDERS = {"ND", "NA", "N/A", "NULL", "-"}


def _category_key(value: str) -> str:
    text = unicodedata.normalize("NFKD", str(value).casefold())
    text = "".join(ch for ch in text if not unicodedata.combining(ch))
    return " ".join(sorted(text.split()))


def _risk_label(value):
    if pd.isna(value):
        return None
    if value <= 5:
        return "Sin riesgo"
    if value <= 14:
        return "Riesgo bajo"
    if value <= 35:
        return "Riesgo medio"
    if value <= 80:
        return "Riesgo alto"
    return "Inviable sanitariamente"


def _numeric(series: pd.Series) -> pd.Series:
    text = series.astype(str).str.strip()
    text = text.str.replace(r"(?<=\d),(?=\d{3}(?:\D|$))", "", regex=True)
    return pd.to_numeric(text, errors="coerce")


def _date_rate(series: pd.Series) -> tuple[pd.Series, float]:
    parsed = pd.to_datetime(series, errors="coerce", format="mixed", utc=True)
    return parsed, float(parsed.notna().mean()) if len(parsed) else 0.0


def infer_types(frame: pd.DataFrame) -> dict:
    result = {}
    n = max(len(frame), 1)
    for name in frame.columns:
        text = frame[name].astype(str).str.strip()
        numeric = _numeric(text)
        valid = numeric.notna()
        placeholders = text.str.upper().isin(PLACEHOLDERS) | text.eq("")
        parsed_dates, date_rate = _date_rate(text)
        unique = int(text.nunique(dropna=True))
        low = name.casefold()
        if unique <= 1:
            kind = "constant"
        elif re.search(r"codigo|c[oó]d|\bid\b", low):
            kind = "identifier"
        elif date_rate >= 0.9 or (
            name.casefold() in {"año", "ano", "year"} and numeric.dropna().between(1900, 2100).all()
        ):
            kind = "temporal"
        elif unique / n >= 0.9 and valid.mean() < 0.8:
            kind = "identifier"
        elif text.str.casefold().isin({"true", "false", "sí", "si", "no", "0", "1"}).mean() >= 0.95:
            kind = "boolean"
        elif valid.mean() >= 0.5 and (placeholders | valid).all():
            kind = (
                "numeric_with_placeholders"
                if (placeholders & ~valid).any()
                else ("integer" if (numeric.dropna() % 1 == 0).all() else "numeric")
            )
        elif valid.mean() >= 0.8:
            kind = "integer" if (numeric.dropna() % 1 == 0).all() else "numeric"
        elif text.str.len().mean() > 80:
            kind = "text"
        else:
            kind = "categorical"
        result[name] = {
            "type": kind,
            "non_empty": int((text != "").sum()),
            "unique": unique,
            "placeholders": int((placeholders & ~valid).sum()),
            "numeric_values": numeric,
            "parsed_dates": parsed_dates,
        }
    return result


def _chart(cid, kind, title, description, data, x=None, y=None):
    return {"id": cid, "type": kind, "title": title, "description": description, "data": data, "x_axis": x, "y_axis": y}


def analyze_frame(frame: pd.DataFrame, filename: str = "archivo") -> dict:
    """Calcula EDA según el contenido recibido, incluso si no es compatible con IRCA."""
    if len(frame) > MAX_EDA_ROWS:
        raise AppError(413, "E_EDA_ROW_LIMIT", f"El EDA admite hasta {MAX_EDA_ROWS:,} filas.")
    inferred = infer_types(frame)
    nrows, ncols = frame.shape
    types = {name: item["type"] for name, item in inferred.items()}
    type_counts = dict(Counter(types.values()))
    duplicates = int(frame.duplicated().sum())
    missing = []
    for name in frame.columns:
        text = frame[name].astype(str).str.strip()
        mask = (text == "") | text.str.upper().isin(PLACEHOLDERS)
        count = int(mask.sum())
        missing.append(
            {
                "column": name,
                "count": count,
                "percent": round(count / max(nrows, 1) * 100, 4),
                "placeholder_count": int((text.str.upper().isin(PLACEHOLDERS) & ~(text == "")).sum()),
            }
        )
    numeric_cols = [name for name, t in types.items() if t in {"numeric", "integer", "numeric_with_placeholders"}]
    numeric = {}
    charts = []
    for name in numeric_cols[:12]:
        values = inferred[name]["numeric_values"].dropna().astype(float)
        if values.empty:
            continue
        q1, q2, q3 = [float(x) for x in values.quantile([0.25, 0.5, 0.75])]
        iqr = q3 - q1
        lower = q1 - 1.5 * iqr
        upper = q3 + 1.5 * iqr
        numeric[name] = {
            "n": int(values.size),
            "mean": float(values.mean()),
            "std": float(values.std(ddof=1)) if len(values) > 1 else 0.0,
            "min": float(values.min()),
            "q1": q1,
            "median": q2,
            "q3": q3,
            "max": float(values.max()),
            "skewness": float(values.skew()) if len(values) > 2 else None,
            "iqr_lower": lower,
            "iqr_upper": upper,
            "outlier_count": int(((values < lower) | (values > upper)).sum()),
        }
        hist, _ = np.histogram(values, bins=min(20, max(5, int(np.sqrt(len(values))))))
        charts.append(
            _chart(
                "hist-" + name,
                "histogram",
                f"Distribución de {name}",
                "Histograma; muestra completa o agregada por intervalos.",
                [{"bin": float(edges), "count": int(count)} for edges, count in zip(_, hist)],
                "bin",
                "count",
            )
        )
        charts.append(
            _chart(
                "box-" + name,
                "box",
                f"Diagrama de caja de {name}",
                "Atípicos según 1,5 veces el rango intercuartílico.",
                [
                    {
                        "min": float(values.min()),
                        "q1": q1,
                        "median": q2,
                        "q3": q3,
                        "max": float(values.max()),
                        "lower": lower,
                        "upper": upper,
                    }
                ],
            )
        )
    categoricals = {}
    equivalent_categories = {}
    for name, kind in types.items():
        if kind not in {"categorical", "boolean", "constant"}:
            continue
        all_counts = frame[name].astype(str).value_counts(dropna=False)
        counts = all_counts.head(15)
        frequency = [
            {"category": str(k), "count": int(v), "proportion": float(v / nrows) if nrows else 0}
            for k, v in counts.items()
        ]
        if len(all_counts) > 15:
            other = int(all_counts.iloc[15:].sum())
            frequency.append({"category": "Otras", "count": other, "proportion": float(other / nrows) if nrows else 0})
        categoricals[name] = {"categories": int(frame[name].nunique(dropna=False)), "frequencies": frequency}
        groups = {}
        for value in frame[name].dropna().astype(str).unique():
            if value.strip() and value.strip().upper() not in PLACEHOLDERS:
                groups.setdefault(_category_key(value), []).append(value)
        equivalents = [values for values in groups.values() if len(values) > 1]
        if equivalents:
            equivalent_categories[name] = equivalents
        charts.append(
            _chart(
                "bar-" + name,
                "bar",
                f"Frecuencias de {name}",
                "Frecuencias de las categorías más comunes.",
                [{"category": x["category"], "count": x["count"]} for x in frequency],
                "category",
                "count",
            )
        )
    temporal = {}
    time_cols = [name for name, t in types.items() if t == "temporal"]
    if time_cols:
        name = time_cols[0]
        series = inferred[name]["parsed_dates"].dropna()
        temporal = {
            "column": name,
            "min": series.min() if len(series) else None,
            "max": series.max() if len(series) else None,
            "periods": sorted(series.dt.year.unique().tolist()) if len(series) else [],
            "missing_periods": [],
        }
        if numeric_cols and len(series):
            num_name = numeric_cols[0]
            paired = pd.DataFrame(
                {"period": inferred[name]["parsed_dates"].dt.year, "value": inferred[num_name]["numeric_values"]}
            ).dropna()
            grouped = paired.groupby("period")["value"].agg(["mean", "count"]).reset_index()
            chart_data = [
                {"period": int(row.period), "mean": float(row.mean), "count": int(row.count)}
                for row in grouped.itertuples()
            ]
            temporal["series"] = {"numeric_column": num_name, "data": chart_data}
            charts.append(
                _chart(
                    "temporal-series",
                    "line",
                    f"Promedio de {num_name} por año",
                    "La serie describe promedios por periodo; no implica causalidad.",
                    chart_data,
                    "period",
                    "mean",
                )
            )
    relations = {}
    group_comparisons = []
    for category in [
        name for name, kind in types.items() if kind == "categorical" and frame[name].nunique(dropna=True) <= 20
    ][:5]:
        for numeric_name in numeric_cols[:3]:
            grouped = (
                pd.DataFrame({"group": frame[category].astype(str), "value": inferred[numeric_name]["numeric_values"]})
                .dropna()
                .groupby("group")["value"]
                .agg(["mean", "median", "count"])
                .reset_index()
            )
            group_comparisons.append(
                {
                    "category": category,
                    "numeric": numeric_name,
                    "groups": [
                        {
                            "category": str(row.group),
                            "mean": float(row["mean"]),
                            "median": float(row["median"]),
                            "n": int(row["count"]),
                        }
                        for _, row in grouped.iterrows()
                    ],
                }
            )
    if group_comparisons:
        relations["numeric_by_category"] = group_comparisons
        relations["interpretation"] = "Asociación observada en este archivo; no implica causalidad."
    if len(numeric_cols) >= 2:
        numeric_frame = pd.DataFrame({c: inferred[c]["numeric_values"] for c in numeric_cols}).dropna()
        pearson = numeric_frame.corr(method="pearson").fillna(0)
        spearman = numeric_frame.corr(method="spearman").fillna(0)
        pairs = []
        for i, a in enumerate(numeric_cols):
            for b in numeric_cols[i + 1 :]:
                pairs.append(
                    {"x": a, "y": b, "pearson": float(pearson.loc[a, b]), "spearman": float(spearman.loc[a, b])}
                )
        pairs.sort(key=lambda p: abs(p["pearson"]), reverse=True)
        relations.update(
            {
                "correlation_pearson": pearson.to_dict(),
                "correlation_spearman": spearman.to_dict(),
                "top_pairs": pairs[:5],
                "interpretation": "Asociación observada en este archivo; no implica causalidad.",
            }
        )
        charts.append(
            _chart(
                "correlation-heatmap",
                "heatmap",
                "Correlación de Pearson",
                "Matriz de asociación lineal entre variables numéricas.",
                [{"x": a, "y": b, "value": float(pearson.loc[a, b])} for a in numeric_cols for b in numeric_cols],
                "x",
                "y",
            )
        )
        for pair in pairs[:2]:
            sample = (
                numeric_frame[[pair["x"], pair["y"]]].sample(min(2000, len(numeric_frame)), random_state=42)
                if len(numeric_frame) > 2000
                else numeric_frame[[pair["x"], pair["y"]]]
            )
            charts.append(
                _chart(
                    "scatter-" + pair["x"] + "-" + pair["y"],
                    "scatter",
                    f"{pair['x']} y {pair['y']}",
                    "Asociación observada; no implica causalidad.",
                    [{"x": float(row[pair["x"]]), "y": float(row[pair["y"]])} for _, row in sample.iterrows()],
                    pair["x"],
                    pair["y"],
                )
            )
    if any(item["count"] for item in missing):
        charts.append(
            _chart(
                "missing-values",
                "hbar",
                "Valores faltantes por variable",
                "Conteo de celdas vacías o tokens no disponibles.",
                [{"column": x["column"], "count": x["count"]} for x in missing if x["count"]],
                "column",
                "count",
            )
        )
    domain = None
    if "IRCA" in frame.columns:
        irca = _numeric(frame["IRCA"])
        domain = {
            "irca_mean": float(irca.mean()),
            "irca_median": float(irca.median()),
            "irca_by_year": [],
            "aggregate_rows": 0,
            "municipal_rows": int(nrows),
        }
        if "Municipio" in frame.columns:
            aggregate = frame["Municipio"].astype(str).eq("#TODOS")
            domain["aggregate_rows"] = int(aggregate.sum())
            domain["municipal_rows"] = int((~aggregate).sum())
        if "Año" in frame.columns:
            years = pd.to_numeric(frame["Año"].astype(str).str.replace(",", "", regex=False), errors="coerce")
            grouped = (
                pd.DataFrame({"year": years, "irca": irca})
                .dropna()
                .groupby("year")["irca"]
                .agg(["mean", "count"])
                .reset_index()
            )
            domain["irca_by_year"] = [
                {"year": int(r.year), "mean": float(r.mean), "n": int(r.count)} for r in grouped.itertuples()
            ]
        if "Nivel de riesgo" in frame.columns:
            declared = frame["Nivel de riesgo"].astype(str).str.strip()
            domain["risk_distribution"] = declared.value_counts().to_dict()
            expected = irca.map(_risk_label)
            canonical = declared.replace({"Bajo riesgo": "Riesgo bajo", "Alto riesgo": "Riesgo alto"})
            domain["declared_level_mismatch_count"] = int(
                (expected.notna() & canonical.notna() & canonical.ne(expected)).sum()
            )
        urban_rural = {}
        for column in ("IRCAurbano", "IRCArural"):
            if column in frame.columns:
                values = frame[column].astype(str).str.strip()
                parsed = _numeric(values)
                urban_rural[column] = {
                    "available_n": int(parsed.notna().sum()),
                    "placeholder_percent": float(values.str.upper().isin(PLACEHOLDERS).mean() * 100),
                }
        domain["urban_rural_availability"] = urban_rural
    observations = [
        f"El archivo contiene {nrows:,} filas y {ncols} columnas.",
        f"Se identificaron {duplicates:,} filas duplicadas.",
    ]
    for item in missing:
        if item["count"]:
            observations.append(
                f"La variable {item['column']} tiene {item['percent']:.1f} % de valores faltantes o no disponibles (n = {item['count']})."
            )
    for name, stats in numeric.items():
        if stats["outlier_count"]:
            observations.append(
                f"La variable {name} presenta {stats['outlier_count']} valores fuera de los límites IQR [{stats['iqr_lower']:.4g}, {stats['iqr_upper']:.4g}]."
            )
    return json_safe(
        {
            "filename": filename,
            "summary": {
                "rows": nrows,
                "columns": ncols,
                "memory_bytes": int(frame.memory_usage(deep=True).sum()),
                "duplicate_rows": duplicates,
                "duplicate_percent": duplicates / max(nrows, 1) * 100,
                "constant_columns": [c for c, t in types.items() if t == "constant"],
                "type_counts": type_counts,
            },
            "types": types,
            "quality": {
                "missing": missing,
                "placeholder_columns": {c: int(x["placeholders"]) for c, x in inferred.items() if x["placeholders"]},
                "equivalent_categories": equivalent_categories,
            },
            "numeric": numeric,
            "categorical": categoricals,
            "temporal": temporal,
            "relations": relations,
            "domain_irca": domain,
            "observations": observations,
            "charts": charts,
        }
    )
