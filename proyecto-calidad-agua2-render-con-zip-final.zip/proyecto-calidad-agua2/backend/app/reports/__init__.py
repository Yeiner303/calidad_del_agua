"""Generación de reportes descargables."""
