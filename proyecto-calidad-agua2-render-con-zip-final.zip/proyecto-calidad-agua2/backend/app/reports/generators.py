"""Reportes PDF, JSON, CSV y XLSX generados desde resultados calculados."""

from __future__ import annotations

import json
from io import BytesIO
from xml.sax.saxutils import escape

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd
from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER
from reportlab.lib.pagesizes import letter
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import inch
from reportlab.platypus import Image, Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle

from app.core.serialization import json_safe


def neutralize(value):
    """Neutraliza contenido que Excel/CSV podría interpretar como fórmula."""
    if isinstance(value, str) and value.startswith(("=", "+", "-", "@")):
        return "'" + value
    return value


def _display_value(value) -> str:
    if value is None:
        return ""
    if isinstance(value, (dict, list, tuple)):
        return json.dumps(value, ensure_ascii=False, default=str)
    return str(value)


def _pdf(title: str, sections: list[tuple[str, object]], charts=None) -> bytes:
    buffer = BytesIO()
    doc = SimpleDocTemplate(
        buffer,
        pagesize=letter,
        rightMargin=0.6 * inch,
        leftMargin=0.6 * inch,
        topMargin=0.65 * inch,
        bottomMargin=0.6 * inch,
    )
    styles = getSampleStyleSheet()
    styles.add(
        ParagraphStyle(
            name="TitleWater",
            parent=styles["Title"],
            textColor=colors.HexColor("#075985"),
            alignment=TA_CENTER,
            fontSize=19,
            leading=23,
        )
    )
    cell_style = ParagraphStyle(
        name="ReportCell",
        parent=styles["BodyText"],
        fontSize=6.7,
        leading=8.4,
        splitLongWords=1,
        wordWrap="CJK",
        spaceAfter=0,
    )
    header_style = ParagraphStyle(
        name="ReportHeaderCell",
        parent=cell_style,
        fontName="Helvetica-Bold",
        textColor=colors.white,
    )

    def cell(value, style=cell_style):
        text = escape(_display_value(value)).replace("\r\n", "<br/>").replace("\n", "<br/>")
        return Paragraph(text, style)

    story = [
        Paragraph(escape(str(title)), styles["TitleWater"]),
        Spacer(1, 8),
        Paragraph("Calidad del Agua · IRCA | Aplicación 1.0.0", styles["Normal"]),
        Spacer(1, 12),
    ]
    weights = {
        "code": 1.0,
        "severity": 0.8,
        "level": 0.9,
        "column": 1.4,
        "expected": 1.2,
        "found": 1.2,
        "affected_rows": 0.9,
        "message": 2.4,
        "suggestion": 1.8,
        "Código": 1.6,
        "Severidad": 0.65,
        "Columna": 1.2,
        "Esperado": 1.0,
        "Encontrado": 1.0,
        "Filas": 0.65,
        "Detalle": 2.4,
        "Fila": 0.65,
        "Departamento": 1.2,
        "Municipio": 1.2,
        "Año": 0.7,
        "IRCA previo": 0.8,
        "IRCA estimado": 0.9,
        "Riesgo": 0.8,
        "Ref. p10": 0.8,
        "Ref. p90": 0.8,
    }
    for heading, body in sections:
        story.append(Paragraph(escape(str(heading)), styles["Heading2"]))
        if isinstance(body, list) and body and isinstance(body[0], dict):
            headers = list(body[0].keys())
            weights_for_table = [
                weights.get(str(header), max(0.8, min(1.8, len(str(header)) / 8))) for header in headers
            ]
            total_weight = sum(weights_for_table)
            col_widths = [doc.width * weight / total_weight for weight in weights_for_table]
            rows = [[cell(header, header_style) for header in headers]]
            rows.extend([[cell(row.get(key, "")) for key in headers] for row in body[:30]])
            table = Table(rows, colWidths=col_widths, repeatRows=1, hAlign="LEFT")
            table.setStyle(
                TableStyle(
                    [
                        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#0e7490")),
                        ("GRID", (0, 0), (-1, -1), 0.25, colors.HexColor("#cbd5e1")),
                        ("VALIGN", (0, 0), (-1, -1), "TOP"),
                        ("LEFTPADDING", (0, 0), (-1, -1), 4),
                        ("RIGHTPADDING", (0, 0), (-1, -1), 4),
                        ("TOPPADDING", (0, 0), (-1, -1), 3),
                        ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
                        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#f1f5f9")]),
                    ]
                )
            )
            story.extend([table, Spacer(1, 7)])
        elif isinstance(body, list):
            story.extend(Paragraph("• " + escape(_display_value(item)), styles["BodyText"]) for item in body)
        elif isinstance(body, dict):
            rows = [[cell(key), cell(value)] for key, value in body.items()]
            table = Table(rows, colWidths=[1.8 * inch, doc.width - 1.8 * inch], hAlign="LEFT")
            table.setStyle(
                TableStyle(
                    [
                        ("GRID", (0, 0), (-1, -1), 0.25, colors.HexColor("#cbd5e1")),
                        ("VALIGN", (0, 0), (-1, -1), "TOP"),
                        ("LEFTPADDING", (0, 0), (-1, -1), 4),
                        ("RIGHTPADDING", (0, 0), (-1, -1), 4),
                        ("TOPPADDING", (0, 0), (-1, -1), 3),
                        ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
                    ]
                )
            )
            story.extend([table, Spacer(1, 7)])
        else:
            story.append(Paragraph(escape(_display_value(body)), styles["BodyText"]))
            story.append(Spacer(1, 7))
    for chart in (charts or [])[:3]:
        data = chart.get("data", [])
        if not data:
            continue
        fig, ax = plt.subplots(figsize=(6.0, 2.6))
        kind = chart.get("type")
        try:
            if kind in {"bar", "hbar"}:
                labels = [str(r.get("category", r.get("column", "")))[:18] for r in data]
                values = [r.get("count", 0) for r in data]
                (ax.barh if kind == "hbar" else ax.bar)(labels, values, color="#0891b2")
                if kind == "bar":
                    ax.tick_params(axis="x", rotation=30)
            elif kind == "box":
                stats = [
                    {
                        "med": item["median"],
                        "q1": item["q1"],
                        "q3": item["q3"],
                        "whislo": max(item["min"], item.get("lower", item["min"])),
                        "whishi": min(item["max"], item.get("upper", item["max"])),
                        "fliers": [],
                        "label": "IRCA",
                    }
                    for item in data
                ]
                ax.bxp(
                    stats,
                    showfliers=False,
                    patch_artist=True,
                    boxprops={"facecolor": "#67e8f9", "edgecolor": "#0e7490"},
                    medianprops={"color": "#075985", "linewidth": 1.5},
                )
            elif kind == "line":
                ax.plot([r.get("period") for r in data], [r.get("mean") for r in data], marker="o", color="#0e7490")
            elif kind == "scatter":
                ax.scatter([r.get("x") for r in data], [r.get("y") for r in data], s=8, alpha=0.45, color="#0e7490")
            elif kind == "histogram":
                ax.bar(
                    [float(round(r.get("bin", 0), 2)) for r in data], [r.get("count", 0) for r in data], color="#0e7490"
                )
            ax.set_title(chart.get("title", ""))
            ax.grid(alpha=0.2)
            img = BytesIO()
            fig.tight_layout()
            fig.savefig(img, format="png", dpi=130)
            plt.close(fig)
            img.seek(0)
            story.append(Image(img, width=6.0 * inch, height=2.55 * inch))
            story.append(Spacer(1, 8))
        except (ValueError, TypeError, KeyError):
            plt.close(fig)
    doc.build(story)
    return buffer.getvalue()


def report_bytes(kind: str, fmt: str, context: dict) -> tuple[bytes, str, str]:
    """Crea el formato pedido y devuelve bytes, MIME y nombre."""
    fmt = fmt.lower()
    payload = json_safe(context)
    if fmt == "json":
        return (
            json.dumps(payload, ensure_ascii=False, indent=2, allow_nan=False).encode("utf-8"),
            "application/json",
            f"{kind}.json",
        )
    if fmt == "pdf":
        sections = []
        charts = payload.get("eda", {}).get("charts", []) if kind == "eda" else []
        if kind == "eda":
            eda = payload.get("eda", {})
            sections = [
                ("Resumen", eda.get("summary", {})),
                ("Calidad de datos", eda.get("quality", {})),
                ("Estadísticas numéricas", eda.get("numeric", {})),
                ("Observaciones", eda.get("observations", [])),
                (
                    "Criterio de atípicos",
                    "Regla IQR: fuera de Q1 - 1,5 × IQR o Q3 + 1,5 × IQR. Asociaciones observadas no implican causalidad.",
                ),
            ]
        elif kind == "compatibility":
            val = payload.get("validation", {})
            expected_columns = [
                {
                    "Columna": item.get("name"),
                    "Obligatoria": item.get("required"),
                    "Tipo esperado": item.get("expected_type"),
                    "Recibida": item.get("received"),
                    "Tipo inferido": item.get("inferred_type"),
                }
                for item in val.get("expected_columns", [])
            ]
            findings = [
                {
                    "Código": item.get("code"),
                    "Severidad": item.get("severity"),
                    "Columna": item.get("column"),
                    "Esperado": item.get("expected"),
                    "Encontrado": item.get("found"),
                    "Filas": item.get("affected_rows"),
                    "Detalle": item.get("message"),
                }
                for item in val.get("findings", [])
            ]
            sections = [
                ("Estado final", val.get("status", "")),
                ("Columnas esperadas", expected_columns),
                ("Hallazgos", findings),
            ]
        elif kind == "predictions":
            summary = payload.get("prediction_summary", {})
            summary_brief = {key: value for key, value in summary.items() if key not in {"top10", "by_department"}}
            fields = {
                "Fila": "fila_archivo",
                "Departamento": "Departamento",
                "Municipio": "Municipio",
                "Año": "Año_pronostico",
                "IRCA previo": "IRCA_entrada",
                "IRCA estimado": "IRCA_pronosticado",
                "Riesgo": "nivel_riesgo_derivado",
                "Ref. p10": "rango_referencia_p10",
                "Ref. p90": "rango_referencia_p90",
            }

            def compact_predictions(items):
                return [{label: item.get(key, "") for label, key in fields.items()} for item in items]

            sections = [("Resumen general", summary_brief)]
            if summary.get("top10"):
                sections.append(("Pronósticos con mayor IRCA", compact_predictions(summary["top10"][:10])))
            if summary.get("by_department"):
                by_department = sorted(summary["by_department"].items(), key=lambda pair: pair[1], reverse=True)[:10]
                sections.append(
                    (
                        "Promedio por departamento",
                        [
                            {"Departamento": name, "IRCA pronosticado promedio": round(value, 2)}
                            for name, value in by_department
                        ],
                    )
                )
            sections.extend(
                [
                    ("Muestra de predicciones", compact_predictions(payload.get("predictions", [])[:15])),
                    (
                        "Limitaciones",
                        "No se muestran probabilidades: es un modelo de regresión. El modelo no incorpora infraestructura, clima, tratamiento ni vigilancia y no sustituye la medición del agua.",
                    ),
                ]
            )
        else:
            sections = [("Comparación y decisión", payload)]
        sections.insert(
            0, ("Archivo analizado", payload.get("filename") or payload.get("dataset_ref", {}).get("filename", ""))
        )
        return _pdf(f"Reporte de {kind}", sections, charts), "application/pdf", f"{kind}.pdf"
    if kind == "predictions" and fmt in {"csv", "xlsx"}:
        rows = payload.get("predictions", [])
        frame = pd.DataFrame(rows).map(neutralize)
        if fmt == "csv":
            return frame.to_csv(index=False).encode("utf-8-sig"), "text/csv; charset=utf-8", "predicciones.csv"
        buffer = BytesIO()
        with pd.ExcelWriter(buffer, engine="openpyxl") as writer:
            frame.to_excel(writer, index=False, sheet_name="Predicciones")
            pd.DataFrame([payload.get("prediction_summary", {})]).map(neutralize).to_excel(
                writer, index=False, sheet_name="Resumen"
            )
            pd.DataFrame(payload.get("validation", {}).get("findings", [])).map(neutralize).to_excel(
                writer, index=False, sheet_name="Advertencias"
            )
        return (
            buffer.getvalue(),
            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            "predicciones.xlsx",
        )
    raise ValueError(f"Formato no admitido para {kind}: {fmt}")
