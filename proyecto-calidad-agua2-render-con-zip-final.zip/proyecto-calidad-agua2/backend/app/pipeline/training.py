"""Pares consecutivos, evaluación cronológica y entrenamiento final."""

from __future__ import annotations

import hashlib
import re

import numpy as np
import pandas as pd
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

from app.pipeline.model import IrcaPipeline


def parse_number(value):
    if pd.isna(value):
        return np.nan
    text = str(value).strip().replace(" ", "")
    if not text or text.upper() in {"ND", "N/A", "NA", "NULL", "-"}:
        return np.nan
    if "," in text and "." in text:
        text = text.replace(",", "")
    elif "," in text:
        text = (
            re.sub(r"(?<=\d),(?=\d{3}(?:$|,))", "", text)
            if re.fullmatch(r"[-+]?\d{1,3}(,\d{3})+", text)
            else text.replace(",", ".")
        )
    return pd.to_numeric(text, errors="coerce")


def make_pairs(frame: pd.DataFrame) -> pd.DataFrame:
    data = frame.copy()
    data["_year"] = pd.to_numeric(data["Año"].astype(str).str.replace(",", "", regex=False), errors="coerce")
    data["_irca"] = data["IRCA"].map(parse_number)
    data["_key"] = (
        data["DepartamentoCodigo"].astype(str).str.strip() + "|" + data["MunicipioCodigo"].astype(str).str.strip()
    )
    data = data.dropna(subset=["_year", "_irca"]).sort_values(["_key", "_year"], kind="stable").copy()
    duplicates = int(data.duplicated(["_key", "_year"]).sum())
    if duplicates:
        raise ValueError(f"Hay {duplicates} claves geográficas repetidas en un mismo año.")
    grouped = data.groupby("_key", sort=False)
    data["target_year"] = grouped["_year"].shift(-1)
    data["target"] = grouped["_irca"].shift(-1)
    pairs = (
        data.loc[data["target_year"].eq(data["_year"] + 1), ["_year", "_irca", "target_year", "target"]].dropna().copy()
    )
    pairs.columns = ["Año_t", "IRCA_t", "Año_objetivo", "IRCA_objetivo"]
    pairs["Año"] = pairs["Año_t"].astype(int).astype(str)
    pairs["IRCA"] = pairs["IRCA_t"].astype(float).astype(str)
    return pairs.reset_index(drop=True)


def metricas(y_true, y_pred):
    return {
        "mae": float(mean_absolute_error(y_true, y_pred)),
        "rmse": float(np.sqrt(mean_squared_error(y_true, y_pred))),
        "r2": float(r2_score(y_true, y_pred)),
        "observations": int(len(y_true)),
    }


def train_and_evaluate(frame: pd.DataFrame):
    """Evalúa holdout temporal y devuelve el artefacto final entrenado en todos los pares."""
    pairs = make_pairs(frame)
    if pairs.empty:
        raise ValueError("No hay transiciones consecutivas para entrenar.")
    latest = int(pairs["Año_objetivo"].max())
    test_start = latest - 2
    train = pairs[pairs["Año_objetivo"] < test_start]
    test = pairs[pairs["Año_objetivo"] >= test_start]
    evaluation_model = IrcaPipeline().fit(train[["Año", "IRCA"]], train["IRCA_objetivo"].to_numpy(dtype=float))
    prediction = evaluation_model.predict(test[["Año", "IRCA"]])
    actual = test["IRCA_objetivo"].to_numpy(dtype=float)
    residuals = actual - prediction
    final = IrcaPipeline().fit(pairs[["Año", "IRCA"]], pairs["IRCA_objetivo"].to_numpy(dtype=float))
    sample = sorted(
        f"{int(row.Año_objetivo)}|{row.IRCA_t:.8f}|{row.IRCA_objetivo:.8f}"
        for row in pairs.itertuples()
        if int(row.Año_objetivo) >= test_start
    )
    evaluation = {
        "protocol": "Separación cronológica; los tres años objetivo más recientes se reservan para prueba.",
        "test_start_year": test_start,
        "latest_target_year": latest,
        "training_pairs": int(len(train)),
        "test_pairs": int(len(test)),
        "metrics": metricas(actual, prediction),
        "persistence_baseline": metricas(actual, test["IRCA_t"].to_numpy(dtype=float)),
        "residual_quantiles": {"p10": float(np.quantile(residuals, 0.10)), "p90": float(np.quantile(residuals, 0.90))},
        "sample_sha256": hashlib.sha256("\n".join(sample).encode()).hexdigest(),
    }
    return {"model": final, "pairs": pairs, "evaluation": evaluation}
