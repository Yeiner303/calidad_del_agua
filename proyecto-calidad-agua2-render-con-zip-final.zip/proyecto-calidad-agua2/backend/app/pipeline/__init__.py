"""Entrenamiento e inferencia reproducibles."""
