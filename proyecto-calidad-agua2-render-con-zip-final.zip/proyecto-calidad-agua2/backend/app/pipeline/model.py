"""Pipeline sklearn estable para pronosticar IRCA(t+1)."""

from __future__ import annotations

from typing import Any

import numpy as np
import pandas as pd
from sklearn.base import BaseEstimator, TransformerMixin
from sklearn.linear_model import LinearRegression
from sklearn.pipeline import Pipeline


class FeatureBuilder(BaseEstimator, TransformerMixin):
    """Construye [IRCA_t, Año_t - 2007] a partir del esquema validado."""

    def fit(self, X: pd.DataFrame, y=None):
        return self

    def transform(self, X: pd.DataFrame) -> np.ndarray:
        year = pd.to_numeric(X["Año"].astype(str).str.replace(",", "", regex=False), errors="raise").to_numpy(
            dtype=float
        )
        irca = pd.to_numeric(X["IRCA"].astype(str).str.strip(), errors="raise").to_numpy(dtype=float)
        return np.column_stack((irca, year - 2007.0))


class IrcaPipeline:
    """Ajuste, predicción recortada y metadatos del modelo lineal."""

    def __init__(self):
        self.pipeline = Pipeline([("features", FeatureBuilder()), ("regression", LinearRegression())])

    def fit(self, X: pd.DataFrame, y: np.ndarray) -> "IrcaPipeline":
        self.pipeline.fit(X, y)
        return self

    def predict(self, X: pd.DataFrame) -> np.ndarray:
        return np.clip(self.pipeline.predict(X), 0.0, 100.0)

    def to_metadata(self) -> dict[str, Any]:
        model: LinearRegression = self.pipeline.named_steps["regression"]
        return {
            "coefficients": [float(model.intercept_), *[float(v) for v in model.coef_]],
            "features": ["IRCA_t", "Año_desde_2007"],
            "year_origin": 2007,
            "clip": [0, 100],
        }
