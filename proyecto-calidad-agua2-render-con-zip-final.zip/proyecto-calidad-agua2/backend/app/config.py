"""Rutas y límites centralizados de la aplicación."""

import os
from pathlib import Path

BACKEND_DIR = Path(__file__).resolve().parents[1]
PROJECT_DIR = BACKEND_DIR.parent
DATA_DIR = BACKEND_DIR / "data"
MODEL_DIR = BACKEND_DIR / "models"
SCHEMA_PATH = BACKEND_DIR / "metadata" / "schema.json"
STORAGE_DIR = BACKEND_DIR / "storage"
RUNS_DIR = STORAGE_DIR / "runs"
UPLOADS_DIR = STORAGE_DIR / "uploads"
LOG_DIR = BACKEND_DIR / "logs"
TEST_FILES_DIR = PROJECT_DIR / "test_files"
MAX_UPLOAD_BYTES = int(os.getenv("MAX_UPLOAD_MB", "25")) * 1024 * 1024
MAX_EDA_ROWS = 500_000
STORAGE_TTL_DAYS = int(os.getenv("STORAGE_TTL_DAYS", "7"))
APP_VERSION = "1.0.0"
FRONTEND_ORIGIN = os.getenv("FRONTEND_ORIGIN")
ALLOWED_ORIGINS = [
    "http://localhost:5173",
    "http://127.0.0.1:5173",
    *([FRONTEND_ORIGIN] if FRONTEND_ORIGIN else []),
]
for _path in (RUNS_DIR, UPLOADS_DIR, LOG_DIR, MODEL_DIR):
    _path.mkdir(parents=True, exist_ok=True)
