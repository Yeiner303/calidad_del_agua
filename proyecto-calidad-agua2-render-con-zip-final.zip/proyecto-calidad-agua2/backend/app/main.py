"""Aplicación FastAPI y controladores globales de error."""

from __future__ import annotations

import logging
import runpy
import uuid
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from app.api.router import router
from app.config import ALLOWED_ORIGINS, MODEL_DIR
from app.core.errors import AppError
from app.core.logging_config import configure_logging
from app.versioning.registry import read_registry

configure_logging()
logger = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    if not (MODEL_DIR / "registry.json").exists() or not read_registry().get("active_version"):
        script = __import__("pathlib").Path(__file__).resolve().parents[2] / "scripts" / "bootstrap_model.py"
        runpy.run_path(str(script), run_name="bootstrap_runtime")["main"]()
    yield


app = FastAPI(
    title="Calidad del Agua · IRCA",
    description="API de validación, EDA, predicción y versionamiento del modelo IRCA.",
    version="1.0.0",
    lifespan=lifespan,
)
app.add_middleware(
    CORSMiddleware,
    allow_origins=ALLOWED_ORIGINS,
    allow_credentials=False,
    allow_methods=["GET", "POST"],
    allow_headers=["*"],
)
app.include_router(router)


@app.exception_handler(AppError)
async def app_error_handler(request: Request, exc: AppError):
    detail = exc.detail if isinstance(exc.detail, dict) else {"code": "E_REQUEST", "message": str(exc.detail)}
    return JSONResponse(
        status_code=exc.status_code, content={"error": {**detail, "reference_id": uuid.uuid4().hex[:12]}}
    )


@app.exception_handler(RequestValidationError)
async def request_error_handler(request: Request, exc: RequestValidationError):
    return JSONResponse(
        status_code=422,
        content={
            "error": {
                "code": "E_REQUEST_VALIDATION",
                "message": "Revise los datos enviados y vuelva a intentarlo.",
                "details": exc.errors(),
                "reference_id": uuid.uuid4().hex[:12],
            }
        },
    )


@app.exception_handler(Exception)
async def unexpected_error_handler(request: Request, exc: Exception):
    reference = uuid.uuid4().hex[:12]
    logger.exception("Error inesperado reference_id=%s path=%s", reference, request.url.path)
    return JSONResponse(
        status_code=500,
        content={
            "error": {
                "code": "E_INTERNAL",
                "message": "Ocurrió un error inesperado. Intente nuevamente e informe el código de referencia.",
                "reference_id": reference,
            }
        },
    )
