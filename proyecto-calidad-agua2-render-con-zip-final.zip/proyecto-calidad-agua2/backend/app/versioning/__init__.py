"""Registro y decisiones de versiones del modelo."""
