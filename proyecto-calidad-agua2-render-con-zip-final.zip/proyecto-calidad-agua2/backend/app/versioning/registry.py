"""Registro de versiones con persistencia atómica y exclusión de escrituras."""

from __future__ import annotations

import json
import threading
from contextlib import contextmanager

from app.config import MODEL_DIR

_LOCK = threading.RLock()
REGISTRY_PATH = MODEL_DIR / "registry.json"


@contextmanager
def registry_lock():
    """Bloqueo local simple para serializar cambios al registro."""
    with _LOCK:
        yield


def read_registry() -> dict:
    if not REGISTRY_PATH.exists():
        return {"active_version": None, "versions": [], "pending_candidate": None}
    return json.loads(REGISTRY_PATH.read_text(encoding="utf-8"))


def write_registry(registry: dict) -> None:
    """Escribe el registro mediante archivo temporal y reemplazo atómico."""
    with registry_lock():
        temporary = REGISTRY_PATH.with_suffix(".json.tmp")
        temporary.write_text(json.dumps(registry, ensure_ascii=False, indent=2, allow_nan=False), encoding="utf-8")
        temporary.replace(REGISTRY_PATH)


def get_version(version_id: str) -> dict | None:
    return next((item for item in read_registry()["versions"] if item["id"] == version_id), None)


def active_version() -> dict | None:
    registry = read_registry()
    return next((item for item in registry["versions"] if item["id"] == registry["active_version"]), None)
