"""Persistencia local de archivos y resultados por ejecución."""

from __future__ import annotations

import json
import uuid
from datetime import datetime, timezone
from pathlib import Path

import pandas as pd

from app.config import RUNS_DIR
from app.core.io import read_dataset, safe_filename
from app.core.serialization import json_safe


def create_run(content: bytes, filename: str, kind: str = "analysis") -> tuple[str, Path, pd.DataFrame, list[dict]]:
    """Guarda una copia exacta del archivo y devuelve su tabla leída."""
    run_id = uuid.uuid4().hex[:16]
    directory = RUNS_DIR / run_id
    directory.mkdir(parents=True, exist_ok=False)
    safe = safe_filename(filename)
    original = directory / safe
    original.write_bytes(content)
    frame, notes = read_dataset(content, safe)
    metadata = {
        "run_id": run_id,
        "filename": safe,
        "created_at": datetime.now(timezone.utc).isoformat(),
        "kind": kind,
        "rows": len(frame),
        "columns": len(frame.columns),
    }
    save_json(run_id, "run.json", metadata)
    return run_id, original, frame, notes


def run_dir(run_id: str) -> Path:
    return RUNS_DIR / run_id


def save_json(run_id: str, name: str, payload) -> None:
    (run_dir(run_id) / name).write_text(
        json.dumps(json_safe(payload), ensure_ascii=False, indent=2, allow_nan=False), encoding="utf-8"
    )


def load_json(run_id: str, name: str):
    return json.loads((run_dir(run_id) / name).read_text(encoding="utf-8"))


def get_run(run_id: str) -> dict:
    directory = run_dir(run_id)
    if not directory.is_dir() or not (directory / "run.json").exists():
        return {}
    result = load_json(run_id, "run.json")
    for key, file in (
        ("validation", "validation.json"),
        ("eda", "eda.json"),
        ("prediction_summary", "predictions.json"),
    ):
        if (directory / file).exists():
            result[key] = load_json(run_id, file)
    return result


def find_original(run_id: str) -> Path | None:
    directory = run_dir(run_id)
    if not directory.is_dir():
        return None
    return next((p for p in directory.iterdir() if p.suffix.lower() in {".csv", ".xlsx"}), None)


def load_run_frame(run_id: str):
    path = find_original(run_id)
    if not path:
        return None
    return read_dataset(path.read_bytes(), path.name)[0]


def list_runs() -> list[dict]:
    runs = []
    for path in RUNS_DIR.iterdir():
        if path.is_dir() and (path / "run.json").exists():
            try:
                runs.append(load_json(path.name, "run.json"))
            except (OSError, json.JSONDecodeError):
                continue
    return sorted(runs, key=lambda r: r.get("created_at", ""), reverse=True)
