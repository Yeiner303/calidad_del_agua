"""Aplicativo de análisis de calidad del agua."""
