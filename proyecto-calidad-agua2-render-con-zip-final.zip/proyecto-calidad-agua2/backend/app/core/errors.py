"""Errores HTTP de dominio."""

from fastapi import HTTPException


class AppError(HTTPException):
    """Error con código estable, mensaje comprensible y detalles opcionales."""

    def __init__(self, status_code: int, code: str, message: str, details=None):
        super().__init__(status_code=status_code, detail={"code": code, "message": message, "details": details})
