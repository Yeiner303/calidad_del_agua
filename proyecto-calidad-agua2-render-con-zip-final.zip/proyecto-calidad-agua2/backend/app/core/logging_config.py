"""Configuración de log rotativo del servidor."""

import logging
from logging.handlers import RotatingFileHandler

from app.config import LOG_DIR


def configure_logging() -> None:
    """Registra eventos estructurados en un archivo rotativo."""
    handler = RotatingFileHandler(LOG_DIR / "app.log", maxBytes=2_000_000, backupCount=3, encoding="utf-8")
    handler.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(name)s %(message)s"))
    root = logging.getLogger()
    if not root.handlers:
        root.addHandler(handler)
    root.setLevel(logging.INFO)
