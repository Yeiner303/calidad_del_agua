"""Utilidades compartidas del backend."""
