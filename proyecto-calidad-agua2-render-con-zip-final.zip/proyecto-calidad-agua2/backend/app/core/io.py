"""Lectura segura de archivos CSV y Excel."""

from __future__ import annotations

import csv
import io
import re
import unicodedata
from pathlib import Path

import pandas as pd
from openpyxl import load_workbook

from app.core.errors import AppError

ALLOWED_EXTENSIONS = {".csv", ".xlsx"}


def safe_filename(name: str) -> str:
    """Reduce el nombre a caracteres seguros y elimina rutas."""
    base = Path(name.replace("\\", "/")).name
    cleaned = re.sub(r"[^\w. -]", "_", base, flags=re.UNICODE).strip(" .")
    return (cleaned or "archivo")[:120]


def read_dataset(content: bytes, filename: str) -> tuple[pd.DataFrame, list[dict]]:
    """Lee una tabla como texto para que la validación controle la conversión."""
    suffix = Path(filename).suffix.lower()
    if suffix not in ALLOWED_EXTENSIONS:
        raise AppError(415, "E_EXTENSION", "Use un archivo CSV o XLSX.")
    if not content:
        raise AppError(422, "E_EMPTY_FILE", "El archivo está vacío.")
    notes: list[dict] = []
    try:
        if suffix == ".csv":
            encoding = "utf-8-sig"
            try:
                sample = content[:65536].decode(encoding)
            except UnicodeDecodeError:
                encoding = "latin-1"
                sample = content[:65536].decode(encoding)
                notes.append({"code": "I_LATIN1", "message": "Se leyó el archivo con codificación Latin-1."})
            try:
                delimiter = csv.Sniffer().sniff(sample, delimiters=",;\t").delimiter
            except csv.Error:
                delimiter = ","
            header = next(csv.reader(io.StringIO(sample), delimiter=delimiter), [])
            if len(header) != len(set(header)):
                notes.append(
                    {
                        "code": "E_DUPLICATE_COLUMN",
                        "severity": "error",
                        "message": "El archivo tiene nombres de columna duplicados.",
                    }
                )
            frame = pd.read_csv(
                io.BytesIO(content),
                dtype=str,
                keep_default_na=False,
                encoding=encoding,
                sep=delimiter,
                skip_blank_lines=True,
            )
        else:
            book = pd.ExcelFile(io.BytesIO(content), engine="openpyxl")
            if not book.sheet_names:
                raise ValueError("El libro no contiene hojas.")
            frame = (
                pd.read_excel(book, sheet_name=book.sheet_names[0], dtype=object, keep_default_na=False)
                .fillna("")
                .astype(str)
            )
            if len(book.sheet_names) > 1:
                notes.append(
                    {"code": "I_EXCEL_SHEET", "message": f"Se utilizó la primera hoja: {book.sheet_names[0]}."}
                )
            workbook = load_workbook(io.BytesIO(content), data_only=True, read_only=False)
            worksheet = workbook[book.sheet_names[0]]
            headers = {str(cell.value).strip(): cell.column for cell in worksheet[1] if cell.value is not None}
            code_col = headers.get("MunicipioCodigo")
            if code_col:
                lost_format = False
                for row_number in range(2, worksheet.max_row + 1):
                    cell = worksheet.cell(row=row_number, column=code_col)
                    if (
                        isinstance(cell.value, (int, float))
                        and not isinstance(cell.value, bool)
                        and re.fullmatch(r"0{2,}", str(cell.number_format).split(".")[0])
                    ):
                        lost_format = True
                        break
                if lost_format:
                    notes.append(
                        {
                            "code": "W_MUNICIPIO_ZERO_FORMAT",
                            "severity": "warning",
                            "message": "MunicipioCodigo contiene celdas numéricas con formato de ceros a la izquierda; Excel puede haber quitado ceros del valor.",
                        }
                    )
    except AppError:
        raise
    except Exception as exc:
        raise AppError(
            422, "E_UNREADABLE_FILE", "No fue posible leer el archivo. Verifique el formato y los encabezados."
        ) from exc
    if len(frame.columns) == 0:
        raise AppError(422, "E_NO_HEADERS", "El archivo no contiene encabezados.")
    if frame.empty:
        raise AppError(422, "E_NO_ROWS", "El archivo solo contiene encabezados y no tiene registros.")
    frame.columns = [str(column) for column in frame.columns]
    frame.index = range(2, len(frame) + 2)
    return frame, notes


def normalized_name(name: str) -> str:
    """Normaliza nombres para sugerencias, sin cambiar los encabezados."""
    text = unicodedata.normalize("NFKD", name.strip().casefold())
    return "".join(ch for ch in text if not unicodedata.combining(ch))
