"""Rutas REST de análisis, validación, predicción, reportes y versionamiento."""

from __future__ import annotations

import hashlib
import json
import logging
import re
import shutil
import threading
import unicodedata
from datetime import datetime, timezone
from pathlib import Path
from typing import Literal

import joblib
import numpy as np
import pandas as pd
from fastapi import APIRouter, File, Form, Query, UploadFile
from fastapi.responses import FileResponse, Response
from pydantic import BaseModel, Field

from app.config import DATA_DIR, MAX_UPLOAD_BYTES, MODEL_DIR, SCHEMA_PATH, TEST_FILES_DIR
from app.core.errors import AppError
from app.core.io import read_dataset, safe_filename
from app.core.serialization import json_safe
from app.eda.analyzer import analyze_frame
from app.pipeline.training import make_pairs, metricas, train_and_evaluate
from app.reports.generators import report_bytes
from app.services.runs import (
    create_run,
    find_original,
    get_run,
    list_runs,
    load_run_frame,
    run_dir,
    save_json,
)
from app.validation.validator import validate_frame, validate_training_frame
from app.versioning.registry import active_version, get_version, read_registry, write_registry

router = APIRouter(prefix="/api")
logger = logging.getLogger(__name__)
_MODEL_LOCK = threading.RLock()
_MODEL_CACHE = {"id": None, "model": None}


class DecisionBody(BaseModel):
    justification: str = Field(min_length=10, max_length=1000)


def _active_model():
    version = active_version()
    if not version:
        raise AppError(503, "E_MODEL_UNAVAILABLE", "No hay un modelo activo. Ejecute scripts/bootstrap_model.py.")
    model_id = version["id"]
    with _MODEL_LOCK:
        if _MODEL_CACHE["id"] != model_id:
            artifact = (MODEL_DIR / version["artifact_path"]).resolve()
            if MODEL_DIR.resolve() not in artifact.parents or not artifact.is_file():
                raise AppError(500, "E_MODEL_ARTIFACT", "No se encontró un artefacto válido para el modelo activo.")
            _MODEL_CACHE.update({"id": model_id, "model": joblib.load(artifact)})
        return version, _MODEL_CACHE["model"]


async def _upload(upload: UploadFile | None) -> tuple[bytes, str]:
    if upload is None:
        raise AppError(422, "E_FILE_REQUIRED", "Seleccione un archivo.")
    name = safe_filename(upload.filename or "archivo.csv")
    if Path(name).suffix.lower() not in {".csv", ".xlsx"}:
        raise AppError(415, "E_EXTENSION", "Use un archivo CSV o XLSX.")
    content = await upload.read(MAX_UPLOAD_BYTES + 1)
    if len(content) > MAX_UPLOAD_BYTES:
        raise AppError(413, "E_FILE_TOO_LARGE", "El archivo supera el límite de 25 MB.")
    return content, name


def _risk(value: float) -> str:
    if value <= 5:
        return "Sin riesgo"
    if value <= 14:
        return "Riesgo bajo"
    if value <= 35:
        return "Riesgo medio"
    if value <= 80:
        return "Riesgo alto"
    return "Inviable sanitariamente"


def _geo_key(value: object) -> str:
    text = unicodedata.normalize("NFKD", str(value or ""))
    text = "".join(char for char in text if not unicodedata.combining(char))
    text = text.replace("\ufffd", "")
    text = re.sub(r"[^A-Za-z0-9]+", " ", text).strip().upper()
    aliases = {"CHOC": "CHOCO", "QUIBD": "QUIBDO", "TAD": "TADO"}
    return aliases.get(text, text)


def _reported_number(value: object) -> float | None:
    text = str(value or "").strip().replace(",", "")
    number = pd.to_numeric(text, errors="coerce")
    return float(number) if pd.notna(number) else None


_REGION_ORDER = ["Andina", "Caribe", "Pacífica", "Orinoquía", "Amazonía", "Insular"]
_DEPARTMENT_REGION = {
    "05": "Andina", "11": "Andina", "15": "Andina", "17": "Andina", "25": "Andina",
    "41": "Andina", "54": "Andina", "63": "Andina", "66": "Andina", "68": "Andina", "73": "Andina",
    "08": "Caribe", "13": "Caribe", "20": "Caribe", "23": "Caribe", "44": "Caribe", "47": "Caribe", "70": "Caribe",
    "19": "Pacífica", "27": "Pacífica", "52": "Pacífica", "76": "Pacífica",
    "81": "Orinoquía", "85": "Orinoquía", "50": "Orinoquía", "99": "Orinoquía",
    "91": "Amazonía", "18": "Amazonía", "94": "Amazonía", "95": "Amazonía", "86": "Amazonía", "97": "Amazonía",
    "88": "Insular",
}
_RISK_LABELS = {
    "SIN RIESGO": "Sin riesgo",
    "BAJO RIESGO": "Riesgo bajo",
    "RIESGO BAJO": "Riesgo bajo",
    "RIESGO MEDIO": "Riesgo medio",
    "ALTO RIESGO": "Riesgo alto",
    "RIESGO ALTO": "Riesgo alto",
    "INVIABLE SANITARIAMENTE": "Inviable sanitariamente",
}
_RISK_ORDER = ["Sin riesgo", "Riesgo bajo", "Riesgo medio", "Riesgo alto", "Inviable sanitariamente"]
_SUI_COVERAGE_URL = "https://sui.superservicios.gov.co/Servicios-informativos/Entes-territoriales/Reportes-Administrativos/Coberturas-Sin-Soluciones-Particulares"
_SUI_CONTINUITY_URL = "https://sui.superservicios.gov.co/Reportes-del-sector/Acueducto/Reportes-tecnico-operativos/Continuidad-por-municipio"
_DANE_REGIONS_URL = "https://geoportal.dane.gov.co/servicios/atlas-estadistico/src/Tomo_I_Demografico/%E2%80%A2regiones-geogr%C3%A1ficas.html"


def _round_or_none(value, digits: int = 2):
    return round(float(value), digits) if pd.notna(value) else None


def _regional_analysis(comparison_region: str) -> dict:
    pacifica_region = _REGION_ORDER[2]
    if comparison_region not in set(_REGION_ORDER) - {pacifica_region}:
        raise AppError(422, "E_REGION_INVALID", "Seleccione una region distinta de Pacifica entre Andina, Caribe, Orinoquia, Amazonia e Insular.")

    source_path = DATA_DIR / "Calidad_del_Agua_para_Consumo_Humano_en_Colombia_20261009.csv"
    coverage_path = DATA_DIR / "contextual" / "sui_cobertura_acueducto_municipal_2018_2021.csv"
    if not source_path.is_file():
        raise AppError(503, "E_REGIONAL_DATA_UNAVAILABLE", "No esta disponible el CSV municipal del IRCA.")
    if not coverage_path.is_file():
        raise AppError(503, "E_REGIONAL_CONTEXT_UNAVAILABLE", "No esta disponible el CSV oficial de cobertura municipal del SUI.")
    try:
        frame = pd.read_csv(source_path, dtype=str, keep_default_na=False, encoding="utf-8-sig", low_memory=False)
        coverage = pd.read_csv(coverage_path, dtype=str, keep_default_na=False, encoding="utf-8-sig", low_memory=False)
    except (OSError, UnicodeError, pd.errors.ParserError) as exc:
        logger.exception("No fue posible leer las fuentes del analisis regional")
        raise AppError(503, "E_REGIONAL_DATA_INVALID", "No se pudo leer el CSV del IRCA o el CSV de cobertura del SUI.") from exc

    year_column = "A\u00f1o"
    required = {"DepartamentoCodigo", "MunicipioCodigo", "Municipio", year_column, "IRCA", "Nivel de riesgo"}
    if not required.issubset(frame.columns):
        missing = sorted(required - set(frame.columns))
        raise AppError(503, "E_REGIONAL_COLUMNS_MISSING", "Al CSV del IRCA le faltan columnas necesarias para el analisis regional.", {"missing_columns": missing})
    coverage_required = {"anio", "codigo_divipola", "cobertura_acueducto_pct"}
    if not coverage_required.issubset(coverage.columns):
        missing = sorted(coverage_required - set(coverage.columns))
        raise AppError(503, "E_REGIONAL_CONTEXT_COLUMNS_MISSING", "Al CSV de cobertura del SUI le faltan columnas necesarias para el cruce.", {"missing_columns": missing})

    frame = frame.loc[frame["Municipio"].astype(str).str.strip().ne("#TODOS")].copy()
    frame["department_code"] = frame["DepartamentoCodigo"].astype(str).str.strip().str.zfill(2)
    frame["municipality_code"] = frame["MunicipioCodigo"].astype(str).str.strip().str.zfill(5)
    frame["year"] = pd.to_numeric(frame[year_column].astype(str).str.replace(",", "", regex=False), errors="coerce")
    frame["irca"] = pd.to_numeric(frame["IRCA"].astype(str).str.strip().str.replace(",", "", regex=False), errors="coerce")
    frame = frame.dropna(subset=["year"]).copy()
    frame["year"] = frame["year"].astype(int)
    frame["region"] = frame["department_code"].map(_DEPARTMENT_REGION)
    unassigned_codes = sorted(frame.loc[frame["region"].isna(), "department_code"].dropna().unique().tolist())
    assigned = frame.loc[frame["region"].notna()].copy()

    exact_duplicates = int(assigned.duplicated().sum())
    assigned = assigned.drop_duplicates().copy()
    duplicate_keys = assigned.duplicated(["municipality_code", "year"], keep=False)
    if duplicate_keys.any():
        duplicate_examples = assigned.loc[duplicate_keys, ["municipality_code", "year"]].drop_duplicates().head(10).to_dict(orient="records")
        raise AppError(503, "E_REGIONAL_DUPLICATE_KEYS", "La base tiene mas de un registro municipio-anio; se detuvo la comparacion para evitar agregar duplicados sin justificacion.", {"examples": duplicate_examples})

    coverage["year"] = pd.to_numeric(coverage["anio"], errors="coerce")
    coverage["municipality_code"] = coverage["codigo_divipola"].astype(str).str.strip().str.zfill(5)
    coverage["coverage_pct"] = pd.to_numeric(coverage["cobertura_acueducto_pct"].astype(str).str.strip().str.replace(",", ".", regex=False), errors="coerce")
    coverage = coverage.dropna(subset=["year"]).copy()
    coverage["year"] = coverage["year"].astype(int)
    coverage = coverage.loc[coverage["coverage_pct"].isna() | coverage["coverage_pct"].between(0, 100)].copy()
    if coverage.duplicated(["municipality_code", "year"], keep=False).any():
        raise AppError(503, "E_REGIONAL_CONTEXT_DUPLICATE_KEYS", "La fuente SUI repite codigos municipio-anio; se detuvo el cruce para evitar duplicar observaciones.")

    expected_years = [2018, 2019, 2020, 2021]
    years = sorted(set(expected_years) & set(assigned["year"]) & set(coverage["year"]))
    if not years:
        raise AppError(503, "E_REGIONAL_PERIOD_EMPTY", "No hay anios comunes entre los CSV de IRCA y cobertura del SUI.")
    assigned = assigned.loc[assigned["year"].isin(years)].copy()
    coverage = coverage.loc[coverage["year"].isin(years), ["municipality_code", "year", "coverage_pct"]].copy()
    assigned = assigned.merge(coverage, on=["municipality_code", "year"], how="left", validate="one_to_one", indicator="coverage_match")
    def normalize_risk(value: object, irca_value: float | None) -> str:
        normalized = _geo_key(value)
        if normalized in _RISK_LABELS:
            return _RISK_LABELS[normalized]
        return _risk(float(irca_value)) if irca_value is not None and pd.notna(irca_value) else "Sin dato"

    assigned["risk"] = [normalize_risk(risk, value if pd.notna(value) else None) for risk, value in zip(assigned["Nivel de riesgo"], assigned["irca"])]
    paired_assigned = assigned.loc[assigned["irca"].notna() & assigned["coverage_pct"].notna()].copy()
    annual = []
    for region in _REGION_ORDER:
        region_rows = assigned.loc[assigned["region"].eq(region)]
        paired_region_rows = paired_assigned.loc[paired_assigned["region"].eq(region)]
        for year in years:
            group = region_rows.loc[region_rows["year"].eq(year)]
            paired_group = paired_region_rows.loc[paired_region_rows["year"].eq(year)]
            values = paired_group["irca"].dropna()
            coverage_values = paired_group["coverage_pct"].dropna()
            risk_group = paired_group["risk"]
            risk_counts = risk_group.value_counts()
            risk_total = int(risk_counts.sum())
            risk_distribution = [
                {"category": label, "count": int(risk_counts.get(label, 0)), "percent": _round_or_none(100 * risk_counts.get(label, 0) / risk_total) if risk_total else None}
                for label in _RISK_ORDER
            ]
            observations = int(len(group))
            valid = int(values.count())
            annual.append({
                "region": region,
                "year": year,
                "municipalities_reported": int(group["municipality_code"].nunique()),
                "municipalities_with_irca": int(group.loc[group["irca"].notna(), "municipality_code"].nunique()),
                "municipalities_paired": int(paired_group["municipality_code"].nunique()),
                "observations_total": observations,
                "observations_valid": valid,
                "paired_observations": int(len(paired_group)),
                "irca_missing": observations - int(group["irca"].count()),
                "irca_missing_percent": _round_or_none(100 * (observations - int(group["irca"].count())) / observations) if observations else None,
                "median_irca": _round_or_none(values.median()) if valid else None,
                "mean_irca": _round_or_none(values.mean()) if valid else None,
                "coverage_valid": int(group["coverage_pct"].count()),
                "coverage_missing": observations - int(group["coverage_pct"].count()),
                "median_coverage_pct": _round_or_none(coverage_values.median()) if coverage_values.notna().any() else None,
                "mean_coverage_pct": _round_or_none(coverage_values.mean()) if coverage_values.notna().any() else None,
                "risk_distribution": risk_distribution,
            })

    for year in years:
        year_rows = [row for row in annual if row["year"] == year and row["median_irca"] is not None]
        ordered = sorted(year_rows, key=lambda row: (row["median_irca"], _REGION_ORDER.index(row["region"])))
        last_value = None
        last_rank = 0
        for rank, row in enumerate(ordered, start=1):
            if last_value is None or row["median_irca"] != last_value:
                last_rank = rank
                last_value = row["median_irca"]
            row["rank_median"] = last_rank

    summary = []
    for region in _REGION_ORDER:
        records = [row for row in annual if row["region"] == region]
        medians = [row["median_irca"] for row in records if row["median_irca"] is not None]
        means = [row["mean_irca"] for row in records if row["mean_irca"] is not None]
        coverage_medians = [row["median_coverage_pct"] for row in records if row["median_coverage_pct"] is not None]
        coverage_means = [row["mean_coverage_pct"] for row in records if row["mean_coverage_pct"] is not None]
        ranks = [row.get("rank_median") for row in records if row.get("rank_median") is not None]
        region_rows = assigned.loc[assigned["region"].eq(region)]
        paired_region_rows = paired_assigned.loc[paired_assigned["region"].eq(region)]
        total = int(len(region_rows))
        valid = int(paired_region_rows["irca"].count())
        coverage_valid = int(region_rows["coverage_pct"].count())
        summary.append({
            "region": region,
            "years_with_irca": len(medians),
            "municipalities_unique": int(paired_region_rows["municipality_code"].nunique()),
            "observations_total": total,
            "observations_valid": valid,
            "irca_missing": total - int(region_rows["irca"].count()),
            "irca_missing_percent": _round_or_none(100 * (total - int(region_rows["irca"].count())) / total) if total else None,
            "median_of_annual_medians": _round_or_none(pd.Series(medians).median()) if medians else None,
            "mean_of_annual_medians": _round_or_none(pd.Series(medians).mean()) if medians else None,
            "mean_of_annual_means": _round_or_none(pd.Series(means).mean()) if means else None,
            "mean_annual_rank": _round_or_none(pd.Series(ranks).mean()) if ranks else None,
            "coverage_valid": coverage_valid,
            "coverage_missing": total - coverage_valid,
            "paired_observations": valid,
            "irca_rows_available": int(region_rows["irca"].count()),
            "irca_rows_excluded_for_missing_coverage": int(region_rows["irca"].count() - valid),
            "coverage_median_of_annual_medians_pct": _round_or_none(pd.Series(coverage_medians).median()) if coverage_medians else None,
            "coverage_mean_of_annual_means_pct": _round_or_none(pd.Series(coverage_means).mean()) if coverage_means else None,
        })
    summary.sort(key=lambda row: (row["median_of_annual_medians"] is None, row["median_of_annual_medians"] if row["median_of_annual_medians"] is not None else float("inf")))
    for rank, row in enumerate(summary, start=1):
        row["rank_summary_median"] = rank

    comparison_annual = []
    median_gaps = []
    mean_gaps = []
    coverage_median_gaps = []
    coverage_mean_gaps = []
    for year in years:
        pacifica = next(row for row in annual if row["region"] == pacifica_region and row["year"] == year)
        selected = next(row for row in annual if row["region"] == comparison_region and row["year"] == year)
        median_gap = _round_or_none(selected["median_irca"] - pacifica["median_irca"]) if pacifica["median_irca"] is not None and selected["median_irca"] is not None else None
        mean_gap = _round_or_none(selected["mean_irca"] - pacifica["mean_irca"]) if pacifica["mean_irca"] is not None and selected["mean_irca"] is not None else None
        coverage_median_gap = _round_or_none(selected["median_coverage_pct"] - pacifica["median_coverage_pct"]) if pacifica["median_coverage_pct"] is not None and selected["median_coverage_pct"] is not None else None
        coverage_mean_gap = _round_or_none(selected["mean_coverage_pct"] - pacifica["mean_coverage_pct"]) if pacifica["mean_coverage_pct"] is not None and selected["mean_coverage_pct"] is not None else None
        if median_gap is not None:
            median_gaps.append(median_gap)
        if mean_gap is not None:
            mean_gaps.append(mean_gap)
        if coverage_median_gap is not None:
            coverage_median_gaps.append(coverage_median_gap)
        if coverage_mean_gap is not None:
            coverage_mean_gaps.append(coverage_mean_gap)
        comparison_annual.append({
            "year": year,
            "pacifica": pacifica,
            "selected": selected,
            "median_gap_selected_minus_pacifica": median_gap,
            "mean_gap_selected_minus_pacifica": mean_gap,
            "median_coverage_gap_selected_minus_pacifica_pct": coverage_median_gap,
            "mean_coverage_gap_selected_minus_pacifica_pct": coverage_mean_gap,
        })

    paired = assigned.loc[assigned["irca"].notna() & assigned["coverage_pct"].notna(), ["irca", "coverage_pct"]]
    spearman = None
    if len(paired) >= 2:
        spearman = _round_or_none(paired["irca"].rank(method="average").corr(paired["coverage_pct"].rank(method="average")), 4)
    joined_rows = int(assigned["coverage_match"].eq("both").sum())
    coverage_missing = int(assigned["coverage_pct"].isna().sum())
    context_note = (
        f"Se cruzo la cobertura municipal de acueducto del SUI con el IRCA por DIVIPOLA y anio en {min(years)}-{max(years)}. "
        "La cobertura describe disponibilidad reportada del servicio, no potabilidad ni calidad del agua. La asociacion es descriptiva y no demuestra causalidad."
    )
    return {
        "source": {
            "file": source_path.name,
            "period_start": min(years),
            "period_end": max(years),
            "irca_original_period": [int(frame["year"].min()), int(frame["year"].max())],
            "municipal_rows": int(len(assigned)),
            "paired_municipality_years": int(len(paired_assigned)),
            "exact_duplicates_removed": exact_duplicates,
            "unassigned_department_codes": unassigned_codes,
            "regionalization": "Asignacion operativa por codigo DIVIPOLA departamental, basada en DANE; no es una delimitacion municipal oficial.",
            "dane_regions_url": _DANE_REGIONS_URL,
        },
        "years": years,
        "ranking": summary,
        "annual": annual,
        "comparison": {
            "pacifica": pacifica_region,
            "selected_region": comparison_region,
            "regions": [pacifica_region, comparison_region],
            "median_gap_mean_selected_minus_pacifica": _round_or_none(pd.Series(median_gaps).mean()) if median_gaps else None,
            "mean_gap_mean_selected_minus_pacifica": _round_or_none(pd.Series(mean_gaps).mean()) if mean_gaps else None,
            "median_coverage_gap_mean_selected_minus_pacifica_pct": _round_or_none(pd.Series(coverage_median_gaps).mean()) if coverage_median_gaps else None,
            "mean_coverage_gap_mean_selected_minus_pacifica_pct": _round_or_none(pd.Series(coverage_mean_gaps).mean()) if coverage_mean_gaps else None,
            "annual": comparison_annual,
        },
        "context_data": {
            "status": "available",
            "file": coverage_path.name,
            "period_start": min(years),
            "period_end": max(years),
            "municipality_years_joined": joined_rows,
            "municipality_years_unmatched": int(len(assigned) - joined_rows),
            "coverage_missing": coverage_missing,
            "paired_valid_observations": int(len(paired)),
            "spearman_irca_coverage": spearman,
            "note": context_note,
            "sui_coverage_url": _SUI_COVERAGE_URL,
            "sui_continuity_url": _SUI_CONTINUITY_URL,
        },
        "factors_to_investigate": [
            "La cobertura de acueducto por si sola no ordena las medianas regionales de IRCA; la correlacion descriptiva agrupada es cercana a cero y no permite explicar diferencias.",
            "Fuente de captacion, calidad del agua cruda y variacion ambiental.",
            "Disponibilidad, operacion y mantenimiento del tratamiento y la desinfeccion.",
            "Estado de redes, continuidad del servicio, dispersion rural y cobertura de vigilancia.",
        ],
        "limitations": [
            "La comparacion regional se limita al periodo comun 2018-2021; el CSV de IRCA tiene un periodo original mas amplio.",
            "La mediana resume municipios reportados, no representa por si sola a cada habitante o sistema.",
            "Los municipio-anio ausentes o los porcentajes SUI faltantes no equivalen a cero ni permiten medir por si solos la cobertura del universo esperado.",
            "La asignacion por departamento aproxima las seis regiones naturales; algunos limites naturales cruzan departamentos.",
            "Insular corresponde a un solo municipio observado por anio y cuatro municipio-anio en el periodo; su posicion no se debe generalizar.",
            "La cobertura de acueducto no mide continuidad, tratamiento, infraestructura ni potabilidad; las diferencias descriptivas no prueban causalidad.",
        ],
    }

def _prediction(frame: pd.DataFrame, validation: dict, model_version: dict, model) -> tuple[list[dict], dict]:
    years = pd.to_numeric(frame["Año"].astype(str).str.replace(",", "", regex=False), errors="raise").astype(int)
    irca = pd.to_numeric(frame["IRCA"].astype(str).str.strip(), errors="raise").astype(float)
    X = pd.DataFrame({"Año": years.astype(str), "IRCA": irca.astype(str)})
    predicted = model.predict(X)
    q = model_version["evaluation"]["residual_quantiles"]
    rows = []
    for pos, (idx, row) in enumerate(frame.iterrows()):
        value = float(predicted[pos])
        record = {
            "fila_archivo": int(idx),
            "DepartamentoCodigo": row.get("DepartamentoCodigo"),
            "Departamento": row.get("Departamento"),
            "MunicipioCodigo": row.get("MunicipioCodigo"),
            "Municipio": row.get("Municipio"),
            "Año_entrada": int(years.iloc[pos]),
            "IRCA_entrada": float(irca.iloc[pos]),
            "Año_pronostico": int(years.iloc[pos] + 1),
            "IRCA_pronosticado": round(value, 2),
            "cambio_vs_entrada": round(value - float(irca.iloc[pos]), 2),
            "nivel_riesgo_derivado": _risk(value),
            "rango_referencia_p10": round(float(np.clip(value + q["p10"], 0, 100)), 2),
            "rango_referencia_p90": round(float(np.clip(value + q["p90"], 0, 100)), 2),
            "probabilidad": "No aplica (regresión)",
        }
        rows.append(record)
    forecasts = np.array([r["IRCA_pronosticado"] for r in rows], dtype=float)
    changes = np.array([r["cambio_vs_entrada"] for r in rows], dtype=float)
    summary = {
        "count": len(rows),
        "mean": float(forecasts.mean()),
        "median": float(np.median(forecasts)),
        "min": float(forecasts.min()),
        "max": float(forecasts.max()),
        "risk_distribution": pd.Series([r["nivel_riesgo_derivado"] for r in rows]).value_counts().to_dict(),
        "increased": int((changes > 0.005).sum()),
        "decreased": int((changes < -0.005).sum()),
        "unchanged": int((np.abs(changes) <= 0.005).sum()),
        "top10": [r for r in sorted(rows, key=lambda x: x["IRCA_pronosticado"], reverse=True)[:10]],
        "by_department": pd.DataFrame(rows)
        .groupby("Departamento", dropna=False)["IRCA_pronosticado"]
        .mean()
        .sort_values(ascending=False)
        .head(30)
        .to_dict()
        if any(r.get("Departamento") for r in rows)
        else {},
        "model_version": model_version["id"],
        "validation_warnings": [f for f in validation["findings"] if f["severity"] == "warning"],
        "probability": "No aplica (regresión)",
        "reference_range_note": "Rango de referencia basado en el error observado en validación; no es un intervalo de confianza formal ni una probabilidad.",
        "limitations": "El modelo no incorpora infraestructura, clima, tratamiento ni vigilancia y no sustituye la medición del agua.",
    }
    return json_safe(rows), json_safe(summary)


async def _analyze_upload(upload: UploadFile | None, kind: str):
    content, name = await _upload(upload)
    run_id, path, frame, notes = create_run(content, name, kind)
    validation = validate_frame(frame, notes)
    eda = analyze_frame(frame, name)
    save_json(run_id, "validation.json", validation)
    save_json(run_id, "eda.json", eda)
    return run_id, frame, validation, eda, name


@router.get("/health", summary="Estado del servicio")
def health():
    version = active_version()
    return {"status": "ok", "service": "calidad-del-agua-irca", "model_active": version["id"] if version else None}


@router.get("/context/regional", summary="Comparar el IRCA de las seis regiones naturales")
def regional_context(comparacion: str = Query("Andina", alias="comparacion")):
    return _regional_analysis(comparacion)


@router.get("/context/choco-2020", summary="Comparar IRCA y contexto municipal de Chocó en 2020")
def choco_context_2020():
    irca_path = DATA_DIR / "Calidad_del_Agua_para_Consumo_Humano_en_Colombia_20261009.csv"
    context_path = DATA_DIR / "contextual" / "aguas_del_choco_indicadores_pda_2020.csv"
    if not irca_path.is_file() or not context_path.is_file():
        raise AppError(503, "E_CONTEXT_DATA_UNAVAILABLE", "No están disponibles los archivos de contexto territorial de 2020.")

    try:
        irca_frame = pd.read_csv(irca_path, dtype=str, keep_default_na=False, encoding="utf-8-sig")
        context_frame = pd.read_csv(context_path, dtype=str, keep_default_na=False, encoding="utf-8-sig")
    except (OSError, UnicodeError, pd.errors.ParserError) as exc:
        logger.exception("No fue posible leer los datos de comparación contextual")
        raise AppError(503, "E_CONTEXT_DATA_INVALID", "No se pudieron leer los archivos de comparación contextual.") from exc

    context_by_municipality = {
        _geo_key(row["municipio"]): row for row in context_frame.to_dict(orient="records")
    }
    years = pd.to_numeric(irca_frame["Año"].str.replace(",", "", regex=False), errors="coerce")
    department_keys = irca_frame["Departamento"].map(_geo_key)
    municipality_keys = irca_frame["Municipio"].map(_geo_key)
    mask = (years == 2020) & (department_keys == "CHOCO") & (municipality_keys != "TODOS")

    municipalities = []
    for row_index in irca_frame.index[mask]:
        row = irca_frame.loc[row_index]
        key = municipality_keys.loc[row_index]
        context = context_by_municipality.get(key)
        irca_value = _reported_number(row["IRCA"])
        if context is None or irca_value is None:
            continue
        municipalities.append(
            {
                "municipio": context["municipio"],
                "anio": 2020,
                "irca": round(irca_value, 2),
                "riesgo": str(row.get("Nivel de riesgo") or _risk(irca_value)),
                "irca_urbano": _reported_number(row.get("IRCAurbano")),
                "irca_rural": _reported_number(row.get("IRCArural")),
                "calidad_agua_reportada": context.get("calidad_agua_reportada") or "Sin dato",
                "cobertura_redes_reportada": context.get("cobertura_redes_reportada") or "Sin dato",
                "cobertura_servicio_reportada": context.get("cobertura_servicio_reportada") or "Sin dato",
                "continuidad_reportada": context.get("continuidad_reportada") or "Sin dato",
                "estado_infraestructura_reportado": context.get("estado_infraestructura_reportado") or "Sin dato",
                "ptar_reportada": context.get("ptar_reportada") or "Sin dato",
                "prestador": context.get("prestador") or "Sin dato",
            }
        )

    if not municipalities:
        raise AppError(503, "E_CONTEXT_JOIN_EMPTY", "No hubo municipios de Chocó emparejables entre SIVICAP y la ficha PDA de 2020.")
    municipalities.sort(key=lambda item: (-item["irca"], item["municipio"]))
    max_record = municipalities[0]
    min_irca = min(item["irca"] for item in municipalities)
    min_names = [item["municipio"] for item in municipalities if item["irca"] == min_irca]
    return {
        "departamento": "Chocó",
        "anio": 2020,
        "municipalities_count": len(municipalities),
        "highest_irca": {"municipio": max_record["municipio"], "irca": max_record["irca"], "riesgo": max_record["riesgo"]},
        "lowest_irca": {"municipios": min_names, "irca": min_irca},
        "nota": "Comparación exploratoria entre dos reportes de 2020. La etiqueta de calidad de la ficha PDA y el IRCA SIVICAP pueden tener alcances distintos; no prueban causalidad ni garantizan potabilidad en cada hogar.",
        "fuentes": [
            {"nombre": "SIVICAP · Calidad del agua para consumo humano", "archivo": irca_path.name},
            {"nombre": "Aguas del Chocó · Indicadores PDA 2020", "archivo": context_path.name, "url": "https://aguasdelchoco.gov.co/indicadores-pda/"},
        ],
        "municipios": municipalities,
    }


@router.post("/validate", summary="Validar compatibilidad de un archivo")
async def validate(file: UploadFile | None = File(None)):
    run_id, frame, result, eda, name = await _analyze_upload(file, "validation")
    return {"run_id": run_id, "filename": name, "validation": result, "eda_available": True}


@router.post("/eda", summary="Analizar un archivo con EDA dinámico")
async def eda(file: UploadFile | None = File(None)):
    run_id, frame, validation, result, name = await _analyze_upload(file, "eda")
    return {"run_id": run_id, "filename": name, "validation": validation, "eda": result}


@router.post("/predict", summary="Generar predicciones para un archivo compatible")
async def predict(file: UploadFile | None = File(None), run_id: str | None = Form(None)):
    if run_id:
        frame = load_run_frame(run_id)
        if frame is None:
            raise AppError(404, "E_RUN_NOT_FOUND", "No se encontró esa ejecución.")
        run = get_run(run_id)
        name = run["filename"]
        original = find_original(run_id)
        _, notes = read_dataset(original.read_bytes(), original.name)
    else:
        content, name = await _upload(file)
        run_id, original, frame, notes = create_run(content, name, "prediction")
    validation = validate_frame(frame, notes)
    save_json(run_id, "validation.json", validation)
    if validation["status"] == "incompatible":
        raise AppError(
            422,
            "E_INCOMPATIBLE",
            "El archivo no es compatible; revise el diagnóstico de validación.",
            {"run_id": run_id, "validation": validation},
        )
    model_version, model = _active_model()
    predictions, summary = _prediction(frame, validation, model_version, model)
    save_json(run_id, "predictions.json", summary)
    pd.DataFrame(predictions).to_csv(run_dir(run_id) / "predictions.csv", index=False, encoding="utf-8-sig")
    return {
        "run_id": run_id,
        "filename": name,
        "validation": validation,
        "prediction_summary": summary,
        "predictions": predictions,
    }


@router.get("/model/active", summary="Consultar el modelo activo")
def model_active():
    version = active_version()
    if not version:
        raise AppError(503, "E_MODEL_UNAVAILABLE", "No hay un modelo activo.")
    return version


@router.get("/model/schema", summary="Consultar reglas de validación")
def model_schema():
    return json.loads(SCHEMA_PATH.read_text(encoding="utf-8"))


@router.get("/model/versions", summary="Listar versiones del modelo")
def versions():
    return read_registry()["versions"]


@router.get("/model/versions/{version_id}", summary="Consultar una versión")
def version_detail(version_id: str):
    version = get_version(version_id)
    if not version:
        raise AppError(404, "E_VERSION_NOT_FOUND", "No se encontró esa versión.")
    return version


@router.get("/model/candidates/{candidate_id}/comparison", summary="Consultar comparación activa y candidata")
def comparison(candidate_id: str):
    item = get_version(candidate_id)
    if not item or item["status"] != "candidate":
        raise AppError(404, "E_CANDIDATE_NOT_FOUND", "No se encontró una candidata pendiente con ese identificador.")
    return item.get("comparison", {})


@router.post("/model/retrain", summary="Validar datos etiquetados y entrenar una candidata")
async def retrain(file: UploadFile | None = File(None), dry_run: bool = Query(False)):
    content, name = await _upload(file)
    frame, notes = read_dataset(content, name)
    validation = validate_training_frame(frame)
    eda_new = analyze_frame(frame, name)
    if validation["status"] == "incompatible":
        return {"status": "incompatible", "validation": validation, "eda_new": eda_new, "candidate": None}
    registry = read_registry()
    if registry.get("pending_candidate"):
        raise AppError(
            409,
            "E_PENDING_CANDIDATE",
            "Ya existe una candidata pendiente. Promuévala o descártela antes de iniciar otra.",
        )
    active = active_version()
    active_path = DATA_DIR / "training" / "active.csv"
    active_df = pd.read_csv(active_path, dtype=str, keep_default_na=False)
    key_cols = ["DepartamentoCodigo", "MunicipioCodigo", "Año"]
    old_keys = set(
        (
            active_df[key_cols[0]].astype(str).str.strip()
            + "|"
            + active_df[key_cols[1]].astype(str).str.strip()
            + "|"
            + active_df[key_cols[2]].astype(str).str.replace(",", "", regex=False).str.strip()
        ).tolist()
    )
    new_keys = (
        frame[key_cols[0]].astype(str).str.strip()
        + "|"
        + frame[key_cols[1]].astype(str).str.strip()
        + "|"
        + frame[key_cols[2]].astype(str).str.replace(",", "", regex=False).str.strip()
    )
    overlap = new_keys.isin(old_keys)
    if overlap.any():
        finding = {
            "code": "E_KEY_ALREADY_IN_TRAINING",
            "severity": "error",
            "level": "contenido",
            "column": "DepartamentoCodigo|MunicipioCodigo|Año",
            "expected": "claves nuevas",
            "found": "ya existe en el conjunto activo",
            "affected_rows": int(overlap.sum()),
            "sample_rows": [int(x) for x in frame.index[overlap][:20]],
            "message": "Hay claves que ya forman parte del conjunto activo.",
            "suggestion": "Elimine las filas repetidas o entregue años nuevos.",
        }
        validation["findings"].append(finding)
        validation["status"] = "incompatible"
        validation["errors"] += 1
        return {"status": "incompatible", "validation": validation, "eda_new": eda_new, "candidate": None}
    combined = pd.concat([active_df, frame.astype(str)], ignore_index=True)
    try:
        combined_pairs = make_pairs(combined)
    except ValueError as exc:
        raise AppError(422, "E_DUPLICATE_KEY", str(exc))
    old_latest = int(active.get("evaluation", {}).get("latest_target_year", 2024))
    new_pair_count = int((combined_pairs["Año_objetivo"] > old_latest).sum())
    if new_pair_count < 30:
        finding = {
            "code": "E_INSUFFICIENT_NEW_PAIRS",
            "severity": "error",
            "level": "contenido",
            "column": None,
            "expected": "al menos 30 pares consecutivos nuevos",
            "found": new_pair_count,
            "affected_rows": 0,
            "sample_rows": [],
            "message": "Los nuevos registros no generan al menos 30 transiciones nuevas.",
            "suggestion": "Agregue más entidades con años consecutivos.",
        }
        validation["findings"].append(finding)
        validation["status"] = "incompatible"
        validation["errors"] += 1
        return {
            "status": "incompatible",
            "validation": validation,
            "eda_new": eda_new,
            "candidate": None,
            "new_pairs": new_pair_count,
        }
    if dry_run:
        return {
            "status": validation["status"],
            "validation": validation,
            "eda_new": eda_new,
            "updated_dataset_eda": analyze_frame(combined, "conjunto activo más datos nuevos"),
            "new_pairs": new_pair_count,
            "candidate": None,
        }
    trained = train_and_evaluate(combined)
    candidate_id = f"irca-lineal-v{max([int(v['id'].rsplit('v', 1)[-1]) for v in registry['versions'] if v['id'].rsplit('v', 1)[-1].isdigit()] or [1]) + 1}"
    version_dir = MODEL_DIR / candidate_id
    version_dir.mkdir(parents=True, exist_ok=False)
    artifact = version_dir / "pipeline.joblib"
    joblib.dump(trained["model"], artifact)
    candidate_data = DATA_DIR / "training" / "candidates" / f"{candidate_id}.csv"
    candidate_data.parent.mkdir(parents=True, exist_ok=True)
    combined.to_csv(candidate_data, index=False, encoding="utf-8-sig")
    archive_data = DATA_DIR / "training" / "versions"
    archive_data.mkdir(parents=True, exist_ok=True)
    archive_path = archive_data / f"{candidate_id}.csv"
    combined.to_csv(archive_path, index=False, encoding="utf-8-sig")
    current_model_path = (MODEL_DIR / active["artifact_path"]).resolve()
    active_model = joblib.load(current_model_path)
    cutoff = old_latest
    blind = combined_pairs[combined_pairs["Año_objetivo"] > cutoff]
    evaluation_pairs = (
        blind
        if len(blind) >= 30
        else combined_pairs[combined_pairs["Año_objetivo"] >= trained["evaluation"]["test_start_year"]]
    )
    X_eval = pd.DataFrame(
        {"Año": evaluation_pairs["Año_t"].astype(int).astype(str), "IRCA": evaluation_pairs["IRCA_t"].astype(str)}
    )
    y_eval = evaluation_pairs["IRCA_objetivo"].to_numpy(dtype=float)
    active_metrics = metricas(y_eval, active_model.predict(X_eval))
    candidate_metrics = metricas(y_eval, trained["model"].predict(X_eval))
    baseline_metrics = metricas(y_eval, evaluation_pairs["IRCA_t"].to_numpy(dtype=float))
    fair_note = (
        "" if len(blind) >= 30 else "La versión activa pudo haber visto estos años; sus métricas aquí son optimistas."
    )
    comparison_payload = {
        "comparison_base": "prueba ciega común posterior al último año objetivo del modelo activo"
        if len(blind) >= 30
        else "holdout temporal común del protocolo",
        "observations": len(evaluation_pairs),
        "active_metrics": active_metrics,
        "candidate_metrics": candidate_metrics,
        "persistence_baseline": baseline_metrics,
        "absolute_difference": {
            "mae": candidate_metrics["mae"] - active_metrics["mae"],
            "rmse": candidate_metrics["rmse"] - active_metrics["rmse"],
            "r2": candidate_metrics["r2"] - active_metrics["r2"],
        },
        "justice_note": fair_note,
        "new_pairs": new_pair_count,
    }
    metadata = {
        "id": candidate_id,
        "status": "candidate",
        "trained_at": datetime.now(timezone.utc).isoformat(),
        "source_rows": len(combined),
        "training_pairs": len(trained["pairs"]),
        "features": ["IRCA_t", "Año_desde_2007"],
        "algorithm": "Regresión lineal ordinaria (mínimos cuadrados)",
        "model": trained["model"].to_metadata(),
        "evaluation": trained["evaluation"],
        "dataset_ref": {
            "filename": candidate_data.name,
            "sha256": hashlib.sha256(candidate_data.read_bytes()).hexdigest(),
            "storage_path": str(archive_path.relative_to(DATA_DIR)),
        },
        "artifact_path": f"{candidate_id}/pipeline.joblib",
        "parent_version": active["id"],
        "decisions": [],
        "comparison": comparison_payload,
    }
    (version_dir / "metadata.json").write_text(
        json.dumps(metadata, ensure_ascii=False, indent=2, allow_nan=False), encoding="utf-8"
    )
    registry["versions"].append(metadata)
    registry["pending_candidate"] = candidate_id
    write_registry(registry)
    return {
        "status": "candidate",
        "candidate": metadata,
        "validation": validation,
        "eda_new": eda_new,
        "updated_dataset_eda": analyze_frame(combined, "conjunto activo más datos nuevos"),
    }


@router.post("/model/candidates/{candidate_id}/promote", summary="Promover una candidata con justificación")
def promote(candidate_id: str, body: DecisionBody):
    registry = read_registry()
    candidate = next((v for v in registry["versions"] if v["id"] == candidate_id), None)
    if not candidate or candidate["status"] != "candidate":
        raise AppError(404, "E_CANDIDATE_NOT_FOUND", "No se encontró esa candidata pendiente.")
    if registry.get("pending_candidate") != candidate_id:
        raise AppError(409, "E_CANDIDATE_STATE", "La candidata no está pendiente de decisión.")
    previous = next((v for v in registry["versions"] if v["id"] == registry["active_version"]), None)
    now = datetime.now(timezone.utc).isoformat()
    if previous:
        previous["status"] = "historic"
        previous.setdefault("decisions", []).append(
            {"action": "replaced", "at": now, "justification": body.justification}
        )
        (MODEL_DIR / previous["id"] / "metadata.json").write_text(
            json.dumps(previous, ensure_ascii=False, indent=2), encoding="utf-8"
        )
    candidate["status"] = "active"
    candidate.setdefault("decisions", []).append({"action": "promote", "at": now, "justification": body.justification})
    source = DATA_DIR / "training" / candidate["dataset_ref"]["storage_path"]
    if not source.exists():
        raise AppError(500, "E_DATASET_MISSING", "No se encontró el conjunto de datos de esa versión.")
    temporary = DATA_DIR / "training" / "active.tmp.csv"
    shutil.copyfile(source, temporary)
    temporary.replace(DATA_DIR / "training" / "active.csv")
    schema = json.loads(SCHEMA_PATH.read_text(encoding="utf-8"))
    schema["dataset"]["sha256"] = candidate["dataset_ref"]["sha256"]
    schema["active_model"] = {
        "id": candidate_id,
        "trained_at": candidate["trained_at"],
        "primary_metric": "mae",
        "primary_metric_value": candidate["evaluation"]["metrics"]["mae"],
    }
    SCHEMA_PATH.write_text(json.dumps(schema, ensure_ascii=False, indent=2), encoding="utf-8")
    registry["active_version"] = candidate_id
    registry["pending_candidate"] = None
    write_registry(registry)
    with _MODEL_LOCK:
        _MODEL_CACHE.update({"id": None, "model": None})
    (MODEL_DIR / candidate_id / "metadata.json").write_text(
        json.dumps(candidate, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    return {"status": "active", "version": candidate_id, "decision": candidate["decisions"][-1]}


@router.post("/model/candidates/{candidate_id}/discard", summary="Descartar una candidata con justificación")
def discard(candidate_id: str, body: DecisionBody):
    registry = read_registry()
    candidate = next((v for v in registry["versions"] if v["id"] == candidate_id), None)
    if not candidate or candidate["status"] != "candidate":
        raise AppError(404, "E_CANDIDATE_NOT_FOUND", "No se encontró esa candidata pendiente.")
    candidate["status"] = "historic"
    candidate.setdefault("decisions", []).append(
        {"action": "discard", "at": datetime.now(timezone.utc).isoformat(), "justification": body.justification}
    )
    registry["pending_candidate"] = None
    write_registry(registry)
    (MODEL_DIR / candidate_id / "metadata.json").write_text(
        json.dumps(candidate, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    return {"status": "historic", "version": candidate_id, "decision": candidate["decisions"][-1]}


@router.post("/model/versions/{version_id}/activate", summary="Activar una versión histórica")
def activate(version_id: str, body: DecisionBody):
    registry = read_registry()
    target = next((v for v in registry["versions"] if v["id"] == version_id), None)
    if not target:
        raise AppError(404, "E_VERSION_NOT_FOUND", "No se encontró esa versión.")
    if target["status"] == "candidate":
        raise AppError(409, "E_CANDIDATE_PENDING", "Resuelva la candidata pendiente antes de activar otra versión.")
    now = datetime.now(timezone.utc).isoformat()
    previous = next((v for v in registry["versions"] if v["id"] == registry["active_version"]), None)
    if previous and previous["id"] != version_id:
        previous["status"] = "historic"
        previous.setdefault("decisions", []).append(
            {"action": "rollback", "at": now, "justification": body.justification}
        )
    target["status"] = "active"
    target.setdefault("decisions", []).append({"action": "activate", "at": now, "justification": body.justification})
    storage = target.get("dataset_ref", {}).get("storage_path")
    if storage:
        source = DATA_DIR / "training" / storage
        if not source.exists():
            raise AppError(500, "E_DATASET_MISSING", "No se encontró el conjunto de datos de esa versión.")
        tmp = DATA_DIR / "training" / "active.tmp.csv"
        shutil.copyfile(source, tmp)
        tmp.replace(DATA_DIR / "training" / "active.csv")
    registry["active_version"] = version_id
    write_registry(registry)
    with _MODEL_LOCK:
        _MODEL_CACHE.update({"id": None, "model": None})
    return {"status": "active", "version": version_id, "decision": target["decisions"][-1]}


@router.get("/model/versions/{version_id}/report", summary="Descargar reporte de versión")
def version_report(version_id: str, format: Literal["pdf", "json"] = "json"):
    item = get_version(version_id)
    if not item:
        raise AppError(404, "E_VERSION_NOT_FOUND", "No se encontró esa versión.")
    content, mime, name = report_bytes("update", format, item)
    return Response(content, media_type=mime, headers={"Content-Disposition": f'attachment; filename="{name}"'})


@router.get("/runs", summary="Listar ejecuciones")
def runs():
    return list_runs()


@router.get("/runs/{run_id}", summary="Consultar una ejecución")
def run_detail(run_id: str):
    result = get_run(run_id)
    if not result:
        raise AppError(404, "E_RUN_NOT_FOUND", "No se encontró esa ejecución.")
    return result


@router.get("/runs/{run_id}/reports/{kind}", summary="Descargar reporte de una ejecución")
def run_report(
    run_id: str,
    kind: Literal["eda", "compatibility", "predictions"],
    format: Literal["pdf", "csv", "xlsx", "json"] = "pdf",
):
    run = get_run(run_id)
    if not run:
        raise AppError(404, "E_RUN_NOT_FOUND", "No se encontró esa ejecución.")
    context = {
        "filename": run["filename"],
        "validation": run.get("validation", {}),
        "eda": run.get("eda", {}),
        "prediction_summary": run.get("prediction_summary", {}),
        "predictions": [],
    }
    if kind == "predictions":
        path = run_dir(run_id) / "predictions.csv"
        if not path.exists():
            raise AppError(404, "E_REPORT_NOT_READY", "Esta ejecución todavía no tiene predicciones.")
        context["predictions"] = pd.read_csv(path, keep_default_na=False).to_dict(orient="records")
    if kind == "eda" and not context["eda"]:
        raise AppError(404, "E_REPORT_NOT_READY", "Esta ejecución no tiene resultados EDA.")
    if kind == "compatibility" and not context["validation"]:
        raise AppError(404, "E_REPORT_NOT_READY", "Esta ejecución no tiene resultados de validación.")
    try:
        content, mime, name = report_bytes(kind, format, context)
    except ValueError as exc:
        raise AppError(415, "E_REPORT_FORMAT", str(exc))
    return Response(content, media_type=mime, headers={"Content-Disposition": f'attachment; filename="{name}"'})


@router.get("/test-files", summary="Listar archivos demostrativos")
def test_files():
    expected_path = TEST_FILES_DIR / "expected_results.json"
    expected = json.loads(expected_path.read_text(encoding="utf-8")) if expected_path.exists() else {}
    return [
        {
            "name": p.name,
            "description": expected.get(p.name, {}).get("description", "Archivo de prueba"),
            "expected": expected.get(p.name, {}),
        }
        for p in sorted(TEST_FILES_DIR.iterdir())
        if p.is_file() and p.suffix.lower() in {".csv", ".xlsx"}
    ]


@router.get("/test-files/{name}", summary="Descargar archivo demostrativo")
def test_file_download(name: str):
    safe = safe_filename(name)
    path = (TEST_FILES_DIR / safe).resolve()
    if TEST_FILES_DIR.resolve() not in path.parents or not path.is_file():
        raise AppError(404, "E_TEST_FILE_NOT_FOUND", "No se encontró el archivo de prueba.")
    return FileResponse(path, filename=path.name)
