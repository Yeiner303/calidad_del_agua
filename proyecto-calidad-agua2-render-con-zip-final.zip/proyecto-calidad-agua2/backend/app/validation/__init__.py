"""Validación del esquema IRCA."""
