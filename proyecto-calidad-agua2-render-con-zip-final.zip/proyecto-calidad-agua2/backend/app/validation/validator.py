"""Valida estructura, tipos, contenido y dominio desde schema.json."""

from __future__ import annotations

import json

import pandas as pd

from app.config import DATA_DIR, SCHEMA_PATH
from app.core.io import normalized_name

NULLS = {"", "ND", "N/A", "NA", "NULL", "-"}


def _year(series: pd.Series) -> pd.Series:
    return pd.to_numeric(series.astype(str).str.strip().str.replace(",", "", regex=False), errors="coerce")


def _float(series: pd.Series) -> pd.Series:
    return pd.to_numeric(series.astype(str).str.strip(), errors="coerce")


def _risk_for(value):
    if pd.isna(value):
        return None
    if value <= 5:
        return "Sin riesgo"
    if value <= 14:
        return "Riesgo bajo"
    if value <= 35:
        return "Riesgo medio"
    if value <= 80:
        return "Riesgo alto"
    return "Inviable sanitariamente"


def _issue(code, severity, level, column, expected, found, rows, message, suggestion=""):
    return {
        "code": code,
        "severity": severity,
        "level": level,
        "column": column,
        "expected": expected,
        "found": found,
        "affected_rows": len(rows),
        "sample_rows": [int(x) for x in list(rows)[:20]],
        "message": message,
        "suggestion": suggestion,
    }


def _schema():
    return json.loads(SCHEMA_PATH.read_text(encoding="utf-8"))


def validate_frame(frame: pd.DataFrame, read_notes=None) -> dict:
    """Devuelve diagnóstico completo; nunca cambia encabezados ni valores de entrada."""
    schema = _schema()
    columns = schema["columns"]
    known = {col["name"]: col for col in columns}
    received = list(frame.columns)
    issues: list[dict] = []
    required = [col["name"] for col in columns if col["required"]]
    for name in received:
        if name != name.strip():
            issues.append(
                _issue(
                    "W_HEADER_WHITESPACE",
                    "warning",
                    "esquema",
                    name,
                    "nombre sin espacios externos",
                    name,
                    [],
                    "El encabezado tiene espacios externos; no se modificó.",
                    "Corrija el encabezado en el archivo y vuelva a cargarlo.",
                )
            )
    duplicates = sorted({name for name in received if received.count(name) > 1})
    if duplicates:
        issues.append(
            _issue(
                "E_DUPLICATE_COLUMN",
                "error",
                "esquema",
                ", ".join(duplicates),
                "nombres únicos",
                duplicates,
                [],
                "Hay nombres de columna duplicados.",
            )
        )
    for name in required:
        if name not in received:
            close = next((actual for actual in received if normalized_name(actual) == normalized_name(name)), None)
            suggestion = f" Se parece a «{close}», pero el sistema no renombra columnas." if close else ""
            issues.append(
                _issue(
                    "E_MISSING_COLUMN",
                    "error",
                    "esquema",
                    name,
                    "columna requerida",
                    "ausente",
                    [],
                    f"Falta la columna requerida {name}.{suggestion}",
                    "Agregue la columna con el nombre exacto.",
                )
            )
    extras = [name for name in received if name not in known]
    if extras:
        issues.append(
            _issue(
                "W_EXTRA_COLUMNS",
                "warning",
                "esquema",
                ", ".join(extras),
                "columnas definidas por el esquema",
                extras,
                [],
                "Estas columnas adicionales no serán utilizadas por el modelo.",
            )
        )
    ignored = [name for name in received if name in known and not known[name]["used_by_model"]]
    if ignored:
        issues.append(
            _issue(
                "I_IGNORED_COLUMNS",
                "info",
                "esquema",
                ", ".join(ignored),
                "no se usan como predictores",
                ignored,
                [],
                "Las columnas se conservan para trazabilidad, pero no participan en el modelo.",
            )
        )
    for note in read_notes or []:
        issues.append(
            _issue(
                note["code"],
                note.get("severity", "info"),
                "contenido",
                None,
                "lectura de archivo",
                note["message"],
                [],
                note["message"],
            )
        )
    for name in required:
        if name not in received:
            continue
        col = known[name]
        values = frame[name].astype(str).str.strip()
        null_mask = values.str.upper().isin(NULLS)
        null_rows = frame.index[null_mask].tolist()
        if null_rows:
            issues.append(
                _issue(
                    "E_NULLS",
                    "error",
                    "contenido",
                    name,
                    "sin nulos ni tokens ND",
                    f"{len(null_rows)} valores vacíos o no disponibles",
                    null_rows,
                    f"{name} tiene valores faltantes o ND en una columna obligatoria.",
                )
            )
        if name == "Año":
            thousand = values.str.fullmatch(r"\d{1,3}(,\d{3})+").fillna(False)
            if thousand.any():
                rows = frame.index[thousand].tolist()
                issues.append(
                    _issue(
                        "I_YEAR_THOUSANDS",
                        "info",
                        "tipo",
                        "Año",
                        "año entero",
                        "formato con separador de miles",
                        rows,
                        "Se detectó año con separador de miles; se interpretará solo para validación y predicción.",
                    )
                )
            parsed = _year(values)
            bad = parsed.isna() & ~null_mask
            if bad.any():
                rows = frame.index[bad].tolist()
                issues.append(
                    _issue(
                        "E_TYPE",
                        "error",
                        "tipo",
                        name,
                        "entero",
                        "texto no convertible",
                        rows,
                        "Año contiene valores que no se pueden convertir a entero.",
                    )
                )
            fractional = parsed.notna() & (parsed % 1 != 0)
            if fractional.any():
                rows = frame.index[fractional].tolist()
                issues.append(
                    _issue(
                        "E_TYPE", "error", "tipo", name, "entero", "decimal", rows, "Año debe contener años enteros."
                    )
                )
            out = parsed.notna() & ((parsed < 2007) | (parsed > 2100))
            if out.any():
                rows = frame.index[out].tolist()
                vals = values[out].unique()[:5].tolist()
                issues.append(
                    _issue(
                        "E_DOMAIN_RANGE",
                        "error",
                        "dominio",
                        name,
                        "2007 a 2100",
                        vals,
                        rows,
                        "Año está fuera del rango válido [2007, 2100].",
                    )
                )
            soft = parsed.notna() & ((parsed < 2007) | (parsed > 2024))
            if soft.any():
                rows = frame.index[soft].tolist()
                issues.append(
                    _issue(
                        "W_EXTRAPOLATION",
                        "warning",
                        "dominio",
                        name,
                        "rango observado 2007 a 2024",
                        values[soft].unique()[:5].tolist(),
                        rows,
                        "Año queda fuera del rango de entrenamiento; la extrapolación debe interpretarse con cautela.",
                    )
                )
        elif name in {"IRCA", "DepartamentoCodigo"}:
            parsed = _float(values)
            bad = parsed.isna() & ~null_mask
            if name == "DepartamentoCodigo":
                bad |= parsed.notna() & (parsed % 1 != 0)
            if bad.any():
                rows = frame.index[bad].tolist()
                expected = "entero" if name == "DepartamentoCodigo" else "decimal con punto"
                issues.append(
                    _issue(
                        "E_TYPE",
                        "error",
                        "tipo",
                        name,
                        expected,
                        "valor no numérico o formato no admitido",
                        rows,
                        f"{name} contiene valores que no cumplen el tipo esperado.",
                    )
                )
            if name == "IRCA":
                out = parsed.notna() & ((parsed < 0) | (parsed > 100))
                if out.any():
                    rows = frame.index[out].tolist()
                    issues.append(
                        _issue(
                            "E_DOMAIN_RANGE",
                            "error",
                            "dominio",
                            name,
                            "0 a 100",
                            values[out].unique()[:5].tolist(),
                            rows,
                            "IRCA debe estar entre 0 y 100.",
                        )
                    )
    for col in columns:
        name = col["name"]
        if name not in received or col["required"]:
            continue
        values = frame[name].astype(str).str.strip()
        if col["dtype"] == "categorical":
            aliases = col.get("category_aliases", {})
            allowed = set(col.get("categories", [])) | set(aliases)
            nonempty = values[~values.str.upper().isin(NULLS)]
            unknown = sorted(set(nonempty.unique()) - allowed)
            if unknown:
                rows = frame.index[values.isin(unknown)].tolist()
                issues.append(
                    _issue(
                        "W_UNKNOWN_CATEGORY",
                        "warning",
                        "contenido",
                        name,
                        sorted(allowed),
                        unknown,
                        rows,
                        f"{name} contiene categorías no contempladas; la columna es ignorada por el modelo.",
                    )
                )
            found_aliases = [alias for alias in aliases if (values == alias).any() and alias != "ND"]
            if found_aliases:
                rows = frame.index[values.isin(found_aliases)].tolist()
                issues.append(
                    _issue(
                        "I_CATEGORY_ALIAS",
                        "info",
                        "contenido",
                        name,
                        "categorías canónicas",
                        found_aliases,
                        rows,
                        "Se detectaron alias equivalentes; no se fusionaron.",
                    )
                )
            if name == "Nivel de riesgo" and "IRCA" in received:
                irca = _float(frame["IRCA"])
                expected = irca.map(_risk_for)
                canonical = values.replace(aliases)
                mismatch = expected.notna() & canonical.isin(col.get("categories", [])) & canonical.ne(expected)
                if mismatch.any():
                    rows = frame.index[mismatch].tolist()
                    issues.append(
                        _issue(
                            "W_LEVEL_MISMATCH",
                            "warning",
                            "dominio",
                            name,
                            "nivel derivado del IRCA",
                            canonical[mismatch].unique()[:5].tolist(),
                            rows,
                            "El nivel declarado no coincide con el rango del IRCA; no se modificó.",
                        )
                    )
        elif col["dtype"] == "float":
            nonnull = ~values.str.upper().isin(NULLS)
            parsed = _float(values)
            bad = nonnull & parsed.isna()
            if bad.any():
                rows = frame.index[bad].tolist()
                issues.append(
                    _issue(
                        "W_IGNORED_TYPE",
                        "warning",
                        "tipo",
                        name,
                        "valor numérico o ND",
                        "texto no convertible",
                        rows,
                        f"{name} contiene valores no numéricos; la columna no se usa para predecir.",
                    )
                )
            valid = col.get("valid_range")
            if valid:
                out = parsed.notna() & ((parsed < valid[0]) | (parsed > valid[1]))
                if out.any():
                    rows = frame.index[out].tolist()
                    issues.append(
                        _issue(
                            "W_IGNORED_DOMAIN",
                            "warning",
                            "dominio",
                            name,
                            f"{valid[0]} a {valid[1]}",
                            values[out].unique()[:5].tolist(),
                            rows,
                            f"{name} tiene valores fuera de rango en una columna ignorada.",
                        )
                    )
    if "DepartamentoCodigo" in received:
        source = DATA_DIR / "training" / "active.csv"
        if source.exists():
            trained = pd.read_csv(source, dtype=str, keep_default_na=False, usecols=["DepartamentoCodigo"])[
                "DepartamentoCodigo"
            ].astype(str)
            known_depts = set(trained.unique())
            codes = frame["DepartamentoCodigo"].astype(str).str.strip()
            unknown = sorted(set(codes.unique()) - known_depts)
            if unknown:
                rows = frame.index[codes.isin(unknown)].tolist()
                issues.append(
                    _issue(
                        "W_UNKNOWN_DEPARTMENT",
                        "warning",
                        "contenido",
                        "DepartamentoCodigo",
                        "código presente en entrenamiento",
                        unknown,
                        rows,
                        "Hay códigos de departamento no observados en el conjunto de entrenamiento; son identificadores ignorados.",
                    )
                )
    key_columns = ["DepartamentoCodigo", "MunicipioCodigo", "Año"]
    if all(name in received for name in key_columns):
        y = _year(frame["Año"])
        keys = (
            frame["DepartamentoCodigo"].astype(str).str.strip()
            + "|"
            + frame["MunicipioCodigo"].astype(str).str.strip()
            + "|"
            + y.astype("Int64").astype(str)
        )
        duplicated = y.notna() & keys.duplicated(keep=False)
        if duplicated.any():
            rows = frame.index[duplicated].tolist()
            issues.append(
                _issue(
                    "E_DUPLICATE_KEY",
                    "error",
                    "contenido",
                    None,
                    "clave Dep|Mun|Año única",
                    "claves repetidas",
                    rows,
                    "La combinación DepartamentoCodigo, MunicipioCodigo y Año está duplicada.",
                )
            )
    statuses = [item["severity"] for item in issues]
    state = (
        "incompatible" if "error" in statuses else "compatible_with_warnings" if "warning" in statuses else "compatible"
    )
    expected_columns = []
    for col in columns:
        name = col["name"]
        found = name in received
        values = frame[name] if found else pd.Series(dtype=str)
        inferred = "ausente"
        if found:
            if col["dtype"] in {"float", "integer"}:
                parsed = _year(values) if name == "Año" else _float(values)
                inferred = "numeric" if parsed.notna().mean() >= 0.8 else "text"
            elif col["dtype"] == "categorical":
                inferred = "categorical"
            else:
                inferred = "text"
        expected_columns.append(
            {
                "name": name,
                "required": col["required"],
                "expected_type": col["dtype"],
                "received": found,
                "inferred_type": inferred,
            }
        )
    return {
        "status": state,
        "rows": int(len(frame)),
        "columns": int(len(frame.columns)),
        "errors": sum(x["severity"] == "error" for x in issues),
        "warnings": sum(x["severity"] == "warning" for x in issues),
        "infos": sum(x["severity"] == "info" for x in issues),
        "findings": issues,
        "expected_columns": expected_columns,
        "received_columns": received,
        "schema_version": schema["schema_version"],
    }


def validate_training_frame(frame: pd.DataFrame) -> dict:
    result = validate_frame(frame)
    # El reentrenamiento exige las columnas fuente completas para que el objetivo se integre trazablemente.
    for name in [
        "Departamento",
        "Municipio",
        "Nivel de riesgo",
        "IRCAurbano",
        "Nivel de riesgo urbano",
        "IRCArural",
        "Nivel de riesgo rural",
    ]:
        if name not in frame.columns:
            result["findings"].append(
                _issue(
                    "E_MISSING_COLUMN",
                    "error",
                    "esquema",
                    name,
                    "columna requerida para actualización",
                    "ausente",
                    [],
                    "La actualización requiere el esquema completo del conjunto etiquetado.",
                )
            )
    state = (
        "incompatible"
        if any(x["severity"] == "error" for x in result["findings"])
        else "compatible_with_warnings"
        if any(x["severity"] == "warning" for x in result["findings"])
        else "compatible"
    )
    result["status"] = state
    result["errors"] = sum(x["severity"] == "error" for x in result["findings"])
    result["warnings"] = sum(x["severity"] == "warning" for x in result["findings"])
    return result
