import pandas as pd
from app.eda.analyzer import analyze_frame
from app.validation.validator import validate_frame


def frame():
    return pd.DataFrame(
        {
            "DepartamentoCodigo": ["11", "11"],
            "MunicipioCodigo": ["#TODOS", "001"],
            "Año": ["2,024", "2024"],
            "IRCA": ["3.6", "12.4"],
        },
        index=[2, 3],
    )


def test_validation_blocks_missing_and_bad_values():
    missing = validate_frame(frame().drop(columns=["IRCA"]))
    assert missing["status"] == "incompatible"
    assert "E_MISSING_COLUMN" in {x["code"] for x in missing["findings"]}
    broken = frame()
    broken.loc[2, "IRCA"] = "alto"
    assert "E_TYPE" in {x["code"] for x in validate_frame(broken)["findings"]}


def test_validation_accepts_year_thousands_and_warns_extras():
    data = frame()
    data["nota"] = "x"
    result = validate_frame(data)
    codes = {x["code"] for x in result["findings"]}
    assert result["status"] == "compatible_with_warnings"
    assert "I_YEAR_THOUSANDS" in codes and "W_EXTRA_COLUMNS" in codes


def test_eda_handles_lab_data_without_irca():
    data = pd.DataFrame({"fecha_muestreo": ["2024-01-01", "2024-01-02"], "ph": ["7.0", "7.4"], "analista": ["A", "B"]})
    result = analyze_frame(data)
    assert result["summary"]["rows"] == 2
    assert result["temporal"]["column"] == "fecha_muestreo"
    assert "ph" in result["numeric"]


def test_json_safe_replaces_non_finite():
    import numpy as np
    from app.core.serialization import json_safe

    assert json_safe({"x": np.float64(np.nan), "n": np.int64(3)}) == {"x": None, "n": 3}
