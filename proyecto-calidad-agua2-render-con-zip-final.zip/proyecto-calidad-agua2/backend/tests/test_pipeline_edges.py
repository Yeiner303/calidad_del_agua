import pandas as pd
import pytest
from app.pipeline.training import make_pairs


def test_pairs_require_consecutive_years_and_preserve_target():
    data = pd.DataFrame(
        {
            "DepartamentoCodigo": ["11"] * 3,
            "MunicipioCodigo": ["001"] * 3,
            "Año": ["2022", "2023", "2025"],
            "IRCA": ["10", "12", "14"],
        }
    )
    pairs = make_pairs(data)
    assert len(pairs) == 1
    assert int(pairs.iloc[0]["Año_t"]) == 2022
    assert int(pairs.iloc[0]["Año_objetivo"]) == 2023
    assert float(pairs.iloc[0]["IRCA_objetivo"]) == 12


def test_duplicate_key_year_is_an_error():
    data = pd.DataFrame(
        {
            "DepartamentoCodigo": ["11", "11"],
            "MunicipioCodigo": ["001", "001"],
            "Año": ["2022", "2022"],
            "IRCA": ["10", "11"],
        }
    )
    with pytest.raises(ValueError, match="repetidas"):
        make_pairs(data)
