import pandas as pd
from app.validation.validator import validate_frame, validate_training_frame


def basic():
    return pd.DataFrame(
        {
            "DepartamentoCodigo": ["999", "11", "11"],
            "MunicipioCodigo": ["001", "002", "003"],
            "Año": ["2024", "2024", "2,024"],
            "IRCA": ["12.0", "alto", "8.0"],
            "Nivel de riesgo": ["Bajo riesgo", "Riesgo crítico", "Riesgo medio"],
            "IRCAurbano": ["ND", "101", "4.0"],
        },
        index=[2, 3, 4],
    )


def test_finds_unknowns_alias_mismatch_and_ignored_range():
    result = validate_frame(basic())
    codes = {item["code"] for item in result["findings"]}
    assert result["status"] == "incompatible"
    assert {
        "E_TYPE",
        "W_UNKNOWN_CATEGORY",
        "W_UNKNOWN_DEPARTMENT",
        "I_CATEGORY_ALIAS",
        "W_IGNORED_DOMAIN",
        "I_YEAR_THOUSANDS",
    } <= codes


def test_finds_nulls_duplicate_key_and_range_error():
    data = pd.DataFrame(
        {
            "DepartamentoCodigo": ["11", "11"],
            "MunicipioCodigo": ["01", "01"],
            "Año": ["2024", "2024"],
            "IRCA": ["", "187.4"],
        },
        index=[2, 3],
    )
    result = validate_frame(data)
    codes = {item["code"] for item in result["findings"]}
    assert {"E_NULLS", "E_DOMAIN_RANGE", "E_DUPLICATE_KEY"} <= codes


def test_suggests_header_and_reports_whitespace_without_renaming():
    data = pd.DataFrame({"DepartamentoCodigo": ["11"], "MunicipioCodigo": ["01"], " Ano": ["2024"], "IRCA": ["3.4"]})
    result = validate_frame(data)
    codes = {item["code"] for item in result["findings"]}
    assert "W_HEADER_WHITESPACE" in codes
    missing = next(
        item for item in result["findings"] if item["code"] == "E_MISSING_COLUMN" and item["column"] == "Año"
    )
    assert "Ano" not in missing["message"] or "parece" in missing["message"]


def test_training_requires_full_labeled_schema():
    result = validate_training_frame(
        pd.DataFrame({"DepartamentoCodigo": ["11"], "MunicipioCodigo": ["001"], "Año": ["2025"], "IRCA": ["4"]})
    )
    assert result["status"] == "incompatible"
    assert sum(x["code"] == "E_MISSING_COLUMN" for x in result["findings"]) >= 7
