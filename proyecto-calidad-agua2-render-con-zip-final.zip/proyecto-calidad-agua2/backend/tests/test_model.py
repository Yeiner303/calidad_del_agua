import pandas as pd
from app.config import DATA_DIR
from app.pipeline.training import train_and_evaluate


def test_model_reproduces_reference_metrics():
    frame = pd.read_csv(
        DATA_DIR / "Calidad_del_Agua_para_Consumo_Humano_en_Colombia_20261009.csv", dtype=str, keep_default_na=False
    )
    result = train_and_evaluate(frame)
    ev = result["evaluation"]
    assert len(result["pairs"]) == 17666
    assert ev["training_pairs"] == 14728 and ev["test_pairs"] == 2938
    assert ev["test_start_year"] == 2022 and ev["latest_target_year"] == 2024
    assert abs(ev["metrics"]["mae"] - 5.6953) < 1e-3
    assert abs(ev["metrics"]["rmse"] - 9.7417) < 1e-3
    assert abs(ev["metrics"]["r2"] - 0.5893) < 1e-3
    assert abs(ev["persistence_baseline"]["mae"] - 5.9802) < 1e-3
    assert abs(ev["persistence_baseline"]["rmse"] - 10.2541) < 1e-3
    expected = [6.810305, 0.75672768, -0.3311868]
    assert all(abs(a - b) < 1e-5 for a, b in zip(result["model"].to_metadata()["coefficients"], expected))
