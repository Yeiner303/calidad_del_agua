from app.config import TEST_FILES_DIR
from app.main import app
from fastapi.testclient import TestClient


def test_compatible_file_predicts_and_incompatible_is_blocked():
    with TestClient(app) as client:
        good = (TEST_FILES_DIR / "01_compatible.csv").read_bytes()
        validated = client.post("/api/validate", files={"file": ("01_compatible.csv", good, "text/csv")})
        assert validated.status_code == 200
        assert validated.json()["validation"]["status"] in {"compatible", "compatible_with_warnings"}
        prediction = client.post("/api/predict", files={"file": ("01_compatible.csv", good, "text/csv")})
        assert prediction.status_code == 200
        assert len(prediction.json()["predictions"]) > 0
        bad = (TEST_FILES_DIR / "02_falta_columna_irca.csv").read_bytes()
        blocked = client.post("/api/predict", files={"file": ("02_falta_columna_irca.csv", bad, "text/csv")})
        assert blocked.status_code == 422
        assert blocked.json()["error"]["code"] == "E_INCOMPATIBLE"


def test_health_and_report_download():
    with TestClient(app) as client:
        assert client.get("/api/health").json()["model_active"]
        data = (TEST_FILES_DIR / "01_compatible.csv").read_bytes()
        result = client.post("/api/eda", files={"file": ("01_compatible.csv", data, "text/csv")}).json()
        report = client.get(f"/api/runs/{result['run_id']}/reports/eda?format=pdf")
        assert report.status_code == 200 and report.content.startswith(b"%PDF")


def test_report_download_formats():
    from io import BytesIO

    from pypdf import PdfReader

    with TestClient(app) as client:
        data = (TEST_FILES_DIR / "01_compatible.csv").read_bytes()
        uploaded = client.post("/api/validate", files={"file": ("01_compatible.csv", data, "text/csv")})
        assert uploaded.status_code == 200
        run_id = uploaded.json()["run_id"]
        prediction = client.post("/api/predict", data={"run_id": run_id})
        assert prediction.status_code == 200
        formats = {
            "compatibility": {
                "pdf": ("application/pdf", b"%PDF"),
                "json": ("application/json", b"{"),
            },
            "eda": {
                "pdf": ("application/pdf", b"%PDF"),
                "json": ("application/json", b"{"),
            },
            "predictions": {
                "pdf": ("application/pdf", b"%PDF"),
                "csv": ("text/csv", b"\xef\xbb\xbffila_archivo"),
                "xlsx": ("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", b"PK"),
            },
        }
        for kind, outputs in formats.items():
            for fmt, (expected_mime, signature) in outputs.items():
                response = client.get(f"/api/runs/{run_id}/reports/{kind}?format={fmt}")
                assert response.status_code == 200
                assert response.headers["content-type"].startswith(expected_mime)
                assert response.content.startswith(signature)
                if fmt == "pdf":
                    assert len(PdfReader(BytesIO(response.content)).pages) > 0
