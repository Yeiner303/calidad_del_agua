import json

from app.versioning import registry


def test_registry_atomic_write_and_active_lookup(tmp_path, monkeypatch):
    target = tmp_path / "registry.json"
    monkeypatch.setattr(registry, "REGISTRY_PATH", target)
    payload = {
        "active_version": "irca-lineal-v1",
        "pending_candidate": None,
        "versions": [{"id": "irca-lineal-v1", "status": "active"}],
    }
    registry.write_registry(payload)
    assert json.loads(target.read_text(encoding="utf-8")) == payload
    assert registry.active_version()["id"] == "irca-lineal-v1"
    assert registry.get_version("missing") is None


def test_missing_registry_has_empty_state(tmp_path, monkeypatch):
    monkeypatch.setattr(registry, "REGISTRY_PATH", tmp_path / "missing.json")
    assert registry.read_registry() == {"active_version": None, "versions": [], "pending_candidate": None}
