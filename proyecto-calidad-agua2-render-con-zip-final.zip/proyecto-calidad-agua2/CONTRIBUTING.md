# Contribuir

## Flujo de trabajo

1. Confirme con el equipo los integrantes, el curso y el docente antes de completar esos datos en documentación.
2. Cree una rama por integrante y tarea: `feature/<nombre>-<tarea>`. No use nombres de otra persona ni comparta ramas de trabajo.
3. Mantenga cambios acotados a una fase y conserve el esquema central de validación en `backend/metadata/schema.json`.
4. Use commits convencionales: `feat:`, `fix:`, `docs:`, `test:`, `refactor:` o `build:`.
5. Abra un PR a `main`, explique los cambios y adjunte los comandos de verificación ejecutados.
6. Solicite revisión cruzada a otro integrante y resuelva comentarios antes de integrar.
7. No incluya `.venv`, `node_modules`, logs, cargas temporales ni credenciales.

## Verificaciones locales

Backend: `pytest`, `ruff check app scripts`. Frontend: `npm run typecheck`, `npm run lint`, `npm run test`, `npm run build`.

Integrantes: [Completar]  
Curso: [Completar]  
Docente: [Completar]
