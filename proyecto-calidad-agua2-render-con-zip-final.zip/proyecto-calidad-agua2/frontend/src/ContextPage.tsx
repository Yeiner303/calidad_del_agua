import {useMemo,useState} from "react";
import {useQuery} from "@tanstack/react-query";
import {CartesianGrid,Legend,Line,LineChart,ResponsiveContainer,Tooltip,XAxis,YAxis} from "recharts";
import {api} from "./lib/api";
import type {ContextComparison,ContextMunicipality,RegionalAnalysis,RegionalSummary} from "./lib/types";

const format=(value:number|null|undefined)=>value===null||value===undefined?"—":new Intl.NumberFormat("es-CO",{maximumFractionDigits:2}).format(value);
const percent=(value:number|null|undefined)=>value===null||value===undefined?"—":`${format(value)} %`;
const REGIONS=["Andina","Caribe","Pacífica","Orinoquía","Amazonía","Insular"] as const;
const SELECTABLE=REGIONS.filter(region=>region!=="Pacífica");
const COLORS=["#0e7490","#d97706","#be123c","#7c3aed","#15803d","#475569"];

function PageTitle({title,description}:{title:string;description:string}){
 return <div className="mb-6"><p className="eyebrow">IRCA · COLOMBIA</p><h2 className="page-title">{title}</h2><p className="mt-2 max-w-3xl text-sm leading-6 text-slate-600">{description}</p></div>;
}

function Indicator({label,value}:{label:string;value:string}){
 return <div className="metric"><span>{label}</span><strong className="text-base">{value}</strong></div>;
}

function ErrorBox({error}:{error:unknown}){
 if(!error)return null;
 return <div role="alert" className="notice-error">{error instanceof Error?error.message:"No fue posible cargar la comparación."}</div>;
}

function SummaryCard({summary,rank}:{summary:RegionalSummary;rank:number}){
 return <section className="surface">
  <div className="flex flex-wrap items-start justify-between gap-3"><div><p className="eyebrow">Región {rank} · IRCA</p><h3 className="mt-1 text-xl font-semibold">{summary.region}</h3></div><span className="rounded-full bg-cyan-50 px-3 py-1 text-xs font-bold text-cyan-900">Menor mediana = más favorable</span></div>
  <div className="metric-grid mt-4">
   <Indicator label="Mediana de medianas IRCA" value={format(summary.median_of_annual_medians)}/>
   <Indicator label="Promedio de medianas IRCA" value={format(summary.mean_of_annual_medians)}/>
   <Indicator label="Cobertura mediana de acueducto" value={percent(summary.coverage_median_of_annual_medians_pct)}/>
   <Indicator label="Municipios únicos" value={format(summary.municipalities_unique)}/>
   <Indicator label="Pares IRCA y SUI válidos" value={format(summary.paired_observations)}/>
   <Indicator label="Filas sin porcentaje SUI" value={format(summary.coverage_missing)}/>
   <Indicator label="IRCA faltante en el CSV" value={`${format(summary.irca_missing)} (${percent(summary.irca_missing_percent)})`}/>
   <Indicator label="Años con resultado" value={format(summary.years_with_irca)}/>
  </div>
 </section>;
}

function RegionalPanel(){
 const [selectedRegion,setSelectedRegion]=useState<string>("Andina");
 const query=useQuery({queryKey:["regional-context",selectedRegion],queryFn:()=>api<RegionalAnalysis>(`/api/context/regional?comparacion=${encodeURIComponent(selectedRegion)}`)});
 const chartData=useMemo(()=>{
  if(!query.data)return [];
  return query.data.years.map(year=>{
   const row:Record<string,string|number|null>={year};
   for(const region of REGIONS){
    const annual=query.data!.annual.find(item=>item.region===region&&item.year===year);
    row[region]=annual?.median_irca??null;
   }
   return row;
  });
 },[query.data]);
 const coverageChartData=useMemo(()=>{
  if(!query.data)return [];
  return query.data.years.map(year=>{
   const row:Record<string,string|number|null>={year};
   for(const region of REGIONS){
    const annual=query.data!.annual.find(item=>item.region===region&&item.year===year);
    row[region]=annual?.median_coverage_pct??null;
   }
   return row;
  });
 },[query.data]);
 if(query.isLoading)return <div className="surface flex items-center gap-3 text-slate-600"><span className="spinner"/>Calculando el IRCA por región...</div>;
 if(query.error||!query.data)return <ErrorBox error={query.error}/>;
 const data=query.data;
 const selectedSummary=data.ranking.find(row=>row.region===selectedRegion)!;
 const pacificaSummary=data.ranking.find(row=>row.region===data.comparison.pacifica)!;
 const medianGap=data.comparison.median_gap_mean_selected_minus_pacifica;
 const coverageGap=data.comparison.median_coverage_gap_mean_selected_minus_pacifica_pct;
 const medianDirection=medianGap===null?"":medianGap>0?`${selectedRegion} tiene una mediana IRCA promedio más alta que Pacífica`:medianGap<0?`${selectedRegion} tiene una mediana IRCA promedio más baja que Pacífica`:"las medianas IRCA promedio son iguales";
 const best=data.ranking[0];
 const worst=data.ranking[data.ranking.length-1];
 const worstMultiMunicipality=[...data.ranking].reverse().find(row=>row.region!=="Insular");

 return <div className="space-y-4">
  <section className="surface">
   <div className="flex flex-wrap items-end justify-between gap-4">
    <div><p className="eyebrow">Período común IRCA y SUI {data.source.period_start}-{data.source.period_end}</p><h3 className="section-title mt-1">Comparar Pac&iacute;fica con otra región</h3><p className="mt-2 max-w-3xl text-sm leading-6 text-slate-600">Elija una región para comparar las medianas anuales de IRCA y la cobertura municipal de acueducto. Los resúmenes usan municipio-años con ambos valores válidos; menor IRCA es más favorable. La cobertura no indica potabilidad.</p></div>
    <label className="min-w-[220px] text-sm font-semibold text-slate-700">Región para comparar
     <select className="field mt-1 block w-full" value={selectedRegion} onChange={event=>setSelectedRegion(event.target.value)}>
      {SELECTABLE.map(region=><option key={region} value={region}>{region}</option>)}
     </select>
    </label>
   </div>
   <p className="mt-3 rounded-xl border border-cyan-100 bg-cyan-50 p-3 text-sm leading-6 text-cyan-950">{medianDirection}. La diferencia promedio entre medianas regionales es <b>{format(medianGap)} puntos IRCA</b>. En cobertura mediana, la brecha es <b>{format(coverageGap)} puntos porcentuales</b> ({selectedRegion} menos Pac&iacute;fica). Son diferencias descriptivas, no causas.</p>
  </section>

  <div className="grid gap-4 xl:grid-cols-2"><SummaryCard summary={pacificaSummary} rank={pacificaSummary.rank_summary_median}/><SummaryCard summary={selectedSummary} rank={selectedSummary.rank_summary_median}/></div>

  <section className="surface">
   <h3 className="section-title">Mediana anual del IRCA por región</h3>
   <p className="mt-1 text-sm text-slate-600">Comparación con los municipio-años que tienen IRCA y porcentaje SUI válidos. Insular representa una muestra muy pequeña.</p>
   <div className="mt-4 h-80 w-full" role="img" aria-label="Mediana anual del IRCA para las seis regiones">
    <ResponsiveContainer width="100%" height="100%"><LineChart data={chartData} margin={{top:8,right:16,bottom:8,left:4}}><CartesianGrid strokeDasharray="3 3"/><XAxis dataKey="year"/><YAxis label={{value:"Mediana IRCA",angle:-90,position:"insideLeft"}}/><Tooltip formatter={(value)=>format(Number(value))}/><Legend/>{REGIONS.map((region,index)=><Line key={region} type="monotone" dataKey={region} name={region} stroke={COLORS[index]} strokeWidth={region==="Pacífica"||region===selectedRegion?2.8:1.7} dot={false} connectNulls={false}/>)}</LineChart></ResponsiveContainer>
   </div>
   <p className="mt-2 text-xs text-slate-500">Fuente IRCA: CSV municipal SIVICAP entregado. Asignacion operativa por codigo DIVIPOLA departamental.</p>
  </section>

  <section className="surface">
   <h3 className="section-title">Cobertura anual de acueducto por región</h3>
   <p className="mt-1 text-sm text-slate-600">Mediana municipal (%) del SUI en las mismas observaciones emparejadas. Una mayor cobertura reportada no significa que el agua sea potable ni explica por sí sola el IRCA.</p>
   <div className="mt-4 h-80 w-full" role="img" aria-label="Mediana anual de cobertura municipal de acueducto para las seis regiones">
    <ResponsiveContainer width="100%" height="100%"><LineChart data={coverageChartData} margin={{top:8,right:16,bottom:8,left:4}}><CartesianGrid strokeDasharray="3 3"/><XAxis dataKey="year"/><YAxis domain={[0,100]} unit="%" label={{value:"Cobertura",angle:-90,position:"insideLeft"}}/><Tooltip formatter={(value)=>percent(Number(value))}/><Legend/>{REGIONS.map((region,index)=><Line key={region} type="monotone" dataKey={region} name={region} stroke={COLORS[index]} strokeWidth={region==="Pacífica"||region===selectedRegion?2.8:1.7} dot={false} connectNulls={false}/>)}</LineChart></ResponsiveContainer>
   </div>
   <p className="mt-2 text-xs text-slate-500">Fuente: SSPD, capas municipales anuales del Geoportal SIGSUPER, 2018-2021; union por año y DIVIPOLA.</p>
  </section>

  <section className="surface">
   <h3 className="section-title">Ranking regional del período común</h3>
   <p className="mt-1 text-sm text-slate-600">Ordenado por la mediana de las cuatro medianas anuales de IRCA. La cobertura se informa como contexto, con el número de observaciones emparejadas y faltantes.</p>
   <div className="mt-3 overflow-x-auto"><table className="data-table"><thead><tr><th>Puesto</th><th>Región</th><th>Mediana de medianas IRCA</th><th>Promedio de medianas IRCA</th><th>Municipios únicos</th><th>Pares válidos</th><th>Mediana cobertura SUI</th><th>Filas sin cobertura</th></tr></thead><tbody>
    {data.ranking.map(row=><tr key={row.region}><td>{row.rank_summary_median}</td><td className="font-semibold">{row.region}</td><td>{format(row.median_of_annual_medians)}</td><td>{format(row.mean_of_annual_medians)}</td><td>{format(row.municipalities_unique)}</td><td>{format(row.paired_observations)}</td><td>{percent(row.coverage_median_of_annual_medians_pct)}</td><td>{format(row.coverage_missing)}</td></tr>)}
   </tbody></table></div>
   <p className="mt-3 text-sm leading-6 text-slate-700">Mejor resultado observado: <b>{best.region}</b> (mediana {format(best.median_of_annual_medians)}). Mayor mediana: <b>{worst.region}</b> ({format(worst.median_of_annual_medians)}), pero Insular se apoya en solo {worst.paired_observations} pares de un municipio; entre regiones con más municipios, la mediana más alta es la de <b>{worstMultiMunicipality?.region}</b> ({format(worstMultiMunicipality?.median_of_annual_medians)}).</p>
  </section>

  <section className="surface">
   <h3 className="section-title">Diferencias anuales: {selectedRegion} y Pac&iacute;fica</h3>
   <p className="mt-1 text-sm text-slate-600">Cada brecha se calcula como región seleccionada menos Pac&iacute;fica. La brecha de cobertura está en puntos porcentuales.</p>
   <div className="mt-3 overflow-x-auto"><table className="data-table"><thead><tr><th>Año</th><th>IRCA mediano Pac&iacute;fica</th><th>IRCA mediano {selectedRegion}</th><th>Brecha IRCA</th><th>Pares Pac&iacute;fica</th><th>Pares {selectedRegion}</th><th>Cobertura mediana Pac&iacute;fica</th><th>Cobertura mediana {selectedRegion}</th><th>Brecha cobertura</th><th>Sin porcentaje SUI Pac&iacute;fica / {selectedRegion}</th></tr></thead><tbody>
    {data.comparison.annual.map(row=><tr key={row.year}><td>{row.year}</td><td>{format(row.pacifica.median_irca)}</td><td>{format(row.selected.median_irca)}</td><td>{format(row.median_gap_selected_minus_pacifica)}</td><td>{format(row.pacifica.paired_observations)}</td><td>{format(row.selected.paired_observations)}</td><td>{percent(row.pacifica.median_coverage_pct)}</td><td>{percent(row.selected.median_coverage_pct)}</td><td>{format(row.median_coverage_gap_selected_minus_pacifica_pct)} pp</td><td>{row.pacifica.coverage_missing} / {row.selected.coverage_missing}</td></tr>)}
   </tbody></table></div>
  </section>

  <section className="surface border border-amber-200 bg-amber-50">
   <h3 className="section-title">Qué sugiere el cruce y qué queda por investigar</h3>
   <p className="mt-2 text-sm leading-6 text-slate-700">El SUI aportó cobertura de acueducto para este contraste. Se emparejaron {format(data.context_data.municipality_years_joined)} filas por año y DIVIPOLA; {format(data.context_data.coverage_missing)} filas IRCA no tuvieron porcentaje SUI válido y {format(data.context_data.paired_valid_observations)} municipio-años quedaron con ambos valores numéricos. La correlación de rangos agrupada fue {format(data.context_data.spearman_irca_coverage)} (Spearman), cercana a cero. Es una asociación descriptiva de observaciones repetidas; no indica que la cobertura cause el nivel IRCA.</p>
   <p className="mt-2 text-sm leading-6 text-slate-700">La cobertura de acueducto mide disponibilidad reportada del servicio, no calidad ni potabilidad. Los datos no permiten afirmar que una región sea más segura para cada hogar. Diferencias en la fuente de captación, calidad del agua cruda, tratamiento, desinfección, redes, continuidad, dispersión rural y vigilancia son hipótesis por contrastar con indicadores municipales alineados.</p>
   <p className="mt-2 text-sm leading-6 text-slate-700">El ranking es descriptivo. La asignación de región usa el departamento como aproximación a las regiones naturales. Insular tiene un solo municipio en el cruce, por lo que su puesto no se generaliza. Además, IRCA y cobertura solo son comparables en el período común 2018-2021.</p>
   <div className="mt-3 flex flex-wrap gap-x-4 gap-y-2 text-xs"><a className="link-button" href={data.source.dane_regions_url} target="_blank" rel="noreferrer">DANE · Regiones geográficas</a><a className="link-button" href={data.context_data.sui_coverage_url} target="_blank" rel="noreferrer">SSPD / SUI · Cobertura</a><a className="link-button" href={data.context_data.sui_continuity_url} target="_blank" rel="noreferrer">SUI · Continuidad</a><a className="link-button" href="https://www.ins.gov.co/sivicap/Paginas/sivicap.aspx" target="_blank" rel="noreferrer">INS · SIVICAP</a></div>
  </section>

  <p className="text-xs leading-5 text-slate-500">La fuente original IRCA abarca {data.source.irca_original_period[0]}-{data.source.irca_original_period[1]}; esta vista regional usa el período común SUI {data.source.period_start}-{data.source.period_end}. Menor IRCA es más favorable en el indicador, no una certificación actual de potabilidad.</p>
 </div>;
}

function MunicipalityCard({item}:{item:ContextMunicipality}){
 const conflict=item.irca>5&&item.calidad_agua_reportada.toLocaleLowerCase().includes("potable");
 return <section className="surface">
  <div className="flex flex-wrap items-start justify-between gap-3">
   <div><p className="eyebrow">{item.anio} · SIVICAP</p><h3 className="mt-1 text-xl font-semibold">{item.municipio}</h3></div>
   <span className="rounded-full bg-cyan-50 px-3 py-1 text-xs font-bold text-cyan-900">{item.riesgo}</span>
  </div>
  <div className="metric-grid mt-4">
   <Indicator label="IRCA reportado" value={format(item.irca)}/>
   <Indicator label="Calidad en ficha PDA" value={item.calidad_agua_reportada}/>
   <Indicator label="Cobertura en servicio" value={item.cobertura_servicio_reportada}/>
   <Indicator label="Continuidad" value={item.continuidad_reportada}/>
   <Indicator label="Infraestructura" value={item.estado_infraestructura_reportado}/>
   <Indicator label="PTAR" value={item.ptar_reportada}/>
  </div>
  {conflict&&<p className="mt-4 rounded-xl border border-amber-200 bg-amber-50 p-3 text-sm leading-6 text-amber-950"><b>Diferencia entre reportes:</b> SIVICAP registra riesgo para este IRCA y la ficha PDA de 2020 reporta “Potable”. La aplicación conserva ambas etiquetas para revisión; no las equipara.</p>}
  <p className="mt-4 text-xs leading-5 text-slate-500">Prestador reportado: {item.prestador}</p>
 </section>;
}

function ChocoPanel(){
 const query=useQuery({queryKey:["choco-context-2020"],queryFn:()=>api<ContextComparison>("/api/context/choco-2020")});
 const [municipalityA,setMunicipalityA]=useState("Tadó"),[municipalityB,setMunicipalityB]=useState("Quibdó");
 if(query.isLoading)return <div className="surface flex items-center gap-3 text-slate-600"><span className="spinner"/>Cargando la comparación municipal de 2020…</div>;
 if(query.error||!query.data)return <ErrorBox error={query.error}/>;
 const result=query.data,rows=result.municipios;
 const selectedA=rows.find(row=>row.municipio===municipalityA)??rows[0];
 const selectedB=rows.find(row=>row.municipio===municipalityB)??rows.find(row=>row.municipio!==selectedA.municipio)??rows[0];
 const municipalities=rows.map(row=>row.municipio);
 return <div className="space-y-4">
  <section className="surface"><p className="eyebrow">{result.departamento} · {result.anio}</p><h3 className="section-title mt-1">Comparar IRCA y contexto municipal</h3><p className="mt-2 max-w-3xl text-sm leading-6 text-slate-600">Caso local de Chocó en 2020. No representa las seis regiones ni se usa para explicar el ranking regional.</p>
   <div className="mt-3 grid gap-3 sm:grid-cols-2">
    <label className="text-sm font-semibold text-slate-700">Municipio A<select className="field mt-1 block w-full" value={selectedA.municipio} onChange={event=>setMunicipalityA(event.target.value)}>{municipalities.map(name=><option key={name}>{name}</option>)}</select></label>
    <label className="text-sm font-semibold text-slate-700">Municipio B<select className="field mt-1 block w-full" value={selectedB.municipio} onChange={event=>setMunicipalityB(event.target.value)}>{municipalities.map(name=><option key={name}>{name}</option>)}</select></label>
   </div>
   <p className="mt-3 text-xs text-slate-500">Hay {result.municipalities_count} municipios emparejados. IRCA mínimo: {result.lowest_irca.municipios.join(", ")} ({format(result.lowest_irca.irca)}); IRCA máximo: {result.highest_irca.municipio} ({format(result.highest_irca.irca)}, {result.highest_irca.riesgo}).</p>
  </section>
  <div className="grid gap-4 xl:grid-cols-2"><MunicipalityCard item={selectedA}/><MunicipalityCard item={selectedB}/></div>
  <section className="surface"><h3 className="section-title">Registros emparejados</h3><div className="mt-3 overflow-x-auto"><table className="data-table"><thead><tr><th>Municipio</th><th>IRCA SIVICAP</th><th>Riesgo</th><th>Calidad PDA</th><th>Cobertura</th><th>Continuidad</th><th>Infraestructura</th></tr></thead><tbody>{rows.map(row=><tr key={row.municipio}><td className="font-semibold">{row.municipio}</td><td>{format(row.irca)}</td><td>{row.riesgo}</td><td>{row.calidad_agua_reportada}</td><td>{row.cobertura_servicio_reportada}</td><td>{row.continuidad_reportada}</td><td>{row.estado_infraestructura_reportado}</td></tr>)}</tbody></table></div></section>
  <p className="rounded-xl border border-amber-200 bg-amber-50 p-4 text-sm leading-6 text-amber-950"><b>Alcance:</b> {result.nota} La etiqueta “Potable” es la que consigna la ficha fuente; esta vista no certifica agua segura en cada vivienda.</p>
  <div className="text-xs leading-5 text-slate-500">Fuentes: {result.fuentes.map((source,index)=><span key={source.nombre}>{index>0?" · ":""}{source.url?<a className="link-button" href={source.url} target="_blank" rel="noreferrer">{source.nombre}</a>:source.nombre}</span>)}</div>
 </div>;
}

export default function ContextPage(){
 const [view,setView]=useState<"regional"|"choco">("regional");
 return <>
  <PageTitle title="Regiones y contexto del agua" description="Compare el IRCA de las seis regiones y explore los registros. La vista regional separa resultados observados de posibles factores y señala los datos que no están disponibles."/>
  <div role="tablist" aria-label="Vistas de contexto" className="mb-4 flex flex-wrap gap-2">
   <button role="tab" aria-selected={view==="regional"} className={`tab-button ${view==="regional"?"tab-active":""}`} onClick={()=>setView("regional")}>Seis regiones</button>
   <button role="tab" aria-selected={view==="choco"} className={`tab-button ${view==="choco"?"tab-active":""}`} onClick={()=>setView("choco")}>Caso local Chocó 2020</button>
  </div>
  {view==="regional"?<RegionalPanel/>:<ChocoPanel/>}
 </>;
}
