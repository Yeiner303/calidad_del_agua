import type {ApiError} from "./types";
const API_BASE_URL = (import.meta.env.VITE_API_URL ?? '').replace(/\/$/, '');
export function apiUrl(path:string):string{return `${API_BASE_URL}${path}`;}
export class ApiRequestError extends Error {referenceId?:string;code?:string;constructor(message:string,code?:string,referenceId?:string){super(message);this.code=code;this.referenceId=referenceId;}}
export async function api<T>(path:string,init?:RequestInit):Promise<T>{const response=await fetch(apiUrl(path),init);if(!response.ok){let message="No fue posible completar la solicitud.";let code:string|undefined;let reference:string|undefined;try{const data=(await response.json()) as ApiError;message=data.error?.message??message;code=data.error?.code;reference=data.error?.reference_id;}catch{/* Mantiene un mensaje claro ante respuestas no JSON. */}throw new ApiRequestError(message,code,reference);}return await response.json() as T;}
export async function upload<T>(path:string,file:File,extra?:Record<string,string>):Promise<T>{const body=new FormData();body.append("file",file);for(const [key,value] of Object.entries(extra??{}))body.append(key,value);return api<T>(path,{method:"POST",body});}
export function reportUrl(runId:string,kind:string,format:string):string{return apiUrl(`/api/runs/${encodeURIComponent(runId)}/reports/${kind}?format=${format}`);}
