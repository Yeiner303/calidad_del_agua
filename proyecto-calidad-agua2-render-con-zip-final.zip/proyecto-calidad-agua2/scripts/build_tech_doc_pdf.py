"""Genera documento técnico breve y valida que tenga máximo cinco páginas."""

import re
from pathlib import Path
from xml.sax.saxutils import escape

from pypdf import PdfReader
from reportlab.lib.pagesizes import letter
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import inch
from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "docs" / "Documento_Tecnico.md"
OUTPUT = ROOT / "docs" / "Documento_Tecnico.pdf"


def inline_markup(text: str) -> str:
    parts = re.split(r"(`[^`]+`)", text)
    return "".join(
        f'<font name="Courier">{escape(part[1:-1])}</font>'
        if part.startswith("`") and part.endswith("`")
        else escape(part)
        for part in parts
    )


def build():
    styles = getSampleStyleSheet()
    styles.add(
        ParagraphStyle(
            name="TechTitle",
            parent=styles["Title"],
            fontSize=17,
            leading=21,
            textColor="#075985",
            spaceAfter=12,
        )
    )
    story = []
    for line in SOURCE.read_text(encoding="utf-8").splitlines():
        text = line.strip()
        if not text:
            story.append(Spacer(1, 4))
            continue
        if text.startswith("# "):
            story.append(Paragraph(inline_markup(text[2:]), styles["TechTitle"]))
        elif text.startswith("## "):
            story.append(Paragraph(inline_markup(text[3:]), styles["Heading2"]))
        elif text.startswith("- "):
            story.append(Paragraph("- " + inline_markup(text[2:]), styles["BodyText"]))
        else:
            story.append(Paragraph(inline_markup(text), styles["BodyText"]))
    SimpleDocTemplate(
        str(OUTPUT),
        pagesize=letter,
        rightMargin=0.65 * inch,
        leftMargin=0.65 * inch,
        topMargin=0.58 * inch,
        bottomMargin=0.58 * inch,
    ).build(story)
    pages = len(PdfReader(str(OUTPUT)).pages)
    if pages > 5:
        raise SystemExit(f"El documento técnico tiene {pages} páginas; el máximo es 5.")
    print(f"PDF técnico: {pages} páginas ({OUTPUT})")


if __name__ == "__main__":
    build()
