"""Descarga las capas públicas municipales de cobertura de acueducto SSPD/SUI."""

from __future__ import annotations

import csv
import json
import time
from datetime import date
from pathlib import Path
from urllib.parse import urlencode
from urllib.request import Request, urlopen


ROOT = Path(__file__).resolve().parents[1]
OUT_DIR = ROOT / "backend" / "data" / "contextual"
OUT_CSV = OUT_DIR / "sui_cobertura_acueducto_municipal_2018_2021.csv"
OUT_META = OUT_DIR / "fuente_sui_cobertura_acueducto_2018_2021.json"
BASE = "https://geoportal.superservicios.gov.co/server/rest/services/Hosted"
YEARS = (2018, 2019, 2020, 2021)
FIELDS = (
    "dpto_ccdgo",
    "mpio_ccdgo",
    "mpio_cdpmp",
    "dpto_cnmbr",
    "mpio_cnmbr",
    "mpio_tipo",
    "servicio",
    "valor_acue",
    "acueducto",
)
OUTPUT_FIELDS = (
    "anio",
    "codigo_divipola",
    "codigo_departamento",
    "codigo_municipio",
    "departamento_fuente",
    "municipio_fuente",
    "tipo_unidad_fuente",
    "servicio_fuente",
    "cobertura_acueducto_pct",
    "categoria_cobertura_fuente",
    "layer_fuente",
    "url_fuente",
)


def fetch_year(year: int) -> tuple[list[dict], str, str, str]:
    service = f"Cobertura_{year}_Acueducto"
    service_url = f"{BASE}/{service}/FeatureServer"
    layer_url = f"{service_url}/0"
    layer_meta_url = f"{layer_url}?f=pjson"

    offset = 0
    rows: list[dict] = []
    while True:
        params = urlencode(
            {
                "where": "1=1",
                "outFields": ",".join(FIELDS),
                "returnGeometry": "false",
                "resultOffset": offset,
                "resultRecordCount": 2000,
                "orderByFields": "mpio_cdpmp ASC",
                "f": "json",
            }
        )
        query_url = f"{layer_url}/query?{params}"
        request = Request(query_url, headers={"User-Agent": "IRCA-regional-analysis/1.0"})
        for attempt in range(4):
            try:
                with urlopen(request, timeout=60) as response:
                    payload = json.load(response)
                break
            except Exception:
                if attempt == 3:
                    raise
                time.sleep(1.5 * (attempt + 1))
        if payload.get("error"):
            raise RuntimeError(f"Error consultando {service}: {payload['error']}")
        features = payload.get("features", [])
        for feature in features:
            item = feature.get("attributes", {})
            unit = str(item.get("mpio_tipo") or "").strip().upper()
            service_name = str(item.get("servicio") or "Acueducto").strip()
            if unit and unit not in {"MUNICIPIO", "MUNICIPIO ESPECIAL"}:
                continue
            if service_name and service_name.casefold() != "acueducto":
                continue
            code = str(item.get("mpio_cdpmp") or item.get("cod_dane") or "").strip()
            if not code.isdigit() or len(code) != 5:
                continue
            raw_value = item.get("valor_acue")
            try:
                value = float(str(raw_value).replace(",", ".")) if raw_value not in (None, "") else None
            except ValueError:
                value = None
            if value is not None and not 0 <= value <= 100:
                value = None
            rows.append(
                {
                    "anio": year,
                    "codigo_divipola": code,
                    "codigo_departamento": str(item.get("dpto_ccdgo") or code[:2]).zfill(2),
                    "codigo_municipio": str(item.get("mpio_ccdgo") or code[2:]).zfill(3),
                    "departamento_fuente": item.get("dpto_cnmbr"),
                    "municipio_fuente": item.get("mpio_cnmbr"),
                    "tipo_unidad_fuente": unit or "MUNICIPIO",
                    "servicio_fuente": service_name or "Acueducto",
                    "cobertura_acueducto_pct": value,
                    "categoria_cobertura_fuente": item.get("acueducto"),
                    "layer_fuente": service,
                    "url_fuente": f"{layer_url}",
                }
            )
        if len(features) < 2000 or not payload.get("exceededTransferLimit"):
            break
        offset += len(features)
        time.sleep(0.15)
    return rows, service, service_url, layer_meta_url


def main() -> None:
    all_rows: list[dict] = []
    sources = []
    for year in YEARS:
        rows, service, service_url, layer_meta_url = fetch_year(year)
        all_rows.extend(rows)
        sources.append(
            {
                "year": year,
                "title": service,
                "item_id": {
                    2018: "61b97950c2de4e348925bc75eb1de323",
                    2019: "cd2ad474f9c6483888d6d95f434f4f0a",
                    2020: "9459590e0fd3400b914ba11a1980312b",
                    2021: "da2defa50b344d45914e0f33949378ef",
                }[year],
                "service_url": service_url,
                "layer_metadata_url": layer_meta_url,
                "records_downloaded": len(rows),
            }
        )

    keys = [(row["anio"], row["codigo_divipola"]) for row in all_rows]
    duplicates = len(keys) - len(set(keys))
    if duplicates:
        raise RuntimeError(f"Se encontraron {duplicates} filas duplicadas por año y código DIVIPOLA.")

    OUT_DIR.mkdir(parents=True, exist_ok=True)
    with OUT_CSV.open("w", newline="", encoding="utf-8-sig") as stream:
        writer = csv.DictWriter(stream, fieldnames=OUTPUT_FIELDS)
        writer.writeheader()
        writer.writerows(all_rows)

    by_year = {}
    for year in YEARS:
        year_rows = [row for row in all_rows if row["anio"] == year]
        valid = sum(row["cobertura_acueducto_pct"] is not None for row in year_rows)
        by_year[str(year)] = {
            "municipal_rows": len(year_rows),
            "unique_divipola": len({row["codigo_divipola"] for row in year_rows}),
            "coverage_non_null": valid,
            "coverage_null": len(year_rows) - valid,
            "min_coverage_pct": min((row["cobertura_acueducto_pct"] for row in year_rows if row["cobertura_acueducto_pct"] is not None), default=None),
            "max_coverage_pct": max((row["cobertura_acueducto_pct"] for row in year_rows if row["cobertura_acueducto_pct"] is not None), default=None),
        }

    metadata = {
        "dataset": "Cobertura municipal de acueducto reportada a Superservicios",
        "publisher": "Superintendencia de Servicios Públicos Domiciliarios (SSPD), Geoportal SIGSUPER",
        "source_page": "https://sui.superservicios.gov.co/Servicios-informativos/Entes-territoriales/Reportes-Administrativos/Coberturas-Sin-Soluciones-Particulares",
        "geoportal_services_index": "https://geoportal.superservicios.gov.co/server/rest/services/Hosted",
        "retrieved_date": date.today().isoformat(),
        "period": {"start": min(YEARS), "end": max(YEARS), "years": list(YEARS)},
        "geographic_unit": "Municipio, identificado por código DIVIPOLA de cinco dígitos",
        "measure": "valor_acue, cobertura municipal de acueducto expresada como porcentaje; campo de origen publicado por cada FeatureServer anual",
        "source_category": "acueducto, categoría de cobertura reportada en la misma capa anual",
        "join_key": ["anio", "codigo_divipola"],
        "services": sources,
        "method": [
            "Se consultaron las capas FeatureServer públicas anuales de 2018, 2019, 2020 y 2021 alojadas en el Geoportal SIGSUPER de la SSPD.",
            "Se descargaron atributos sin geometría; se conservaron códigos DIVIPOLA, año, cobertura numérica y categoría de cobertura.",
            "Se conservaron únicamente unidades municipales y códigos DIVIPOLA válidos de cinco dígitos; las áreas no municipales se excluyeron.",
            "Los valores numéricos se conservaron entre 0 y 100. Las celdas vacías o valores fuera de ese rango se mantienen como faltantes.",
            "Las etiquetas de cobertura se conservan como fueron reportadas por la fuente; no se usan para reemplazar el porcentaje numérico.",
        ],
        "quality_summary": by_year,
        "duplicate_year_divipola_rows": duplicates,
        "limitations": [
            "Este extracto local cubre 2018–2021 porque son las capas anuales públicas encontradas en el servicio geográfico consultado; la página interactiva del SUI anuncia un rango más amplio, pero no se supuso disponibilidad de una exportación completa para otros años.",
            "La cobertura es un indicador del servicio y no una medición directa de la calidad del agua ni de potabilidad en cada hogar.",
            "La disponibilidad y calidad dependen de la información municipal certificada y de los registros publicados por la fuente.",
            "La regionalización analítica se realiza después del cruce mediante el código departamental; se documenta como aproximación operativa por departamento.",
        ],
    }
    OUT_META.write_text(json.dumps(metadata, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"CSV: {OUT_CSV}")
    print(f"METADATA: {OUT_META}")
    print(json.dumps(by_year, ensure_ascii=False))


if __name__ == "__main__":
    main()
