"""Crea el ZIP entregable sin runtimes, temporales ni estado local."""

from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

ROOT = Path(__file__).resolve().parents[1]
OUTPUT = ROOT / "entrega" / "proyecto-calidad-agua.zip"
EXCLUDED_PARTS = {
    ".git",
    "node_modules",
    "dist",
    "__pycache__",
    ".pytest_cache",
    ".venv",
    ".venv314",
    "storage",
    "logs",
    "work",
    ".ruff_cache",
}


def include(path: Path) -> bool:
    rel = path.relative_to(ROOT)
    if any(part in EXCLUDED_PARTS or part.startswith(".venv") for part in rel.parts):
        return False
    if path.suffix in {".pyc", ".pyo", ".tsbuildinfo"} or path.name == ".coverage":
        return False
    if path.name == ".env" or (
        path.name.startswith(".env.") and path.name != ".env.example"
    ):
        return False
    if rel.parts and rel.parts[0] == "entrega":
        return False
    return path.is_file()


def main():
    OUTPUT.parent.mkdir(parents=True, exist_ok=True)
    files = [p for p in ROOT.rglob("*") if include(p)]
    with ZipFile(OUTPUT, "w", ZIP_DEFLATED, compresslevel=8) as archive:
        for path in files:
            archive.write(path, path.relative_to(ROOT.parent).as_posix())
    print(f"ZIP: {OUTPUT}")
    print(f"Archivos incluidos: {len(files)}")
    with ZipFile(OUTPUT) as archive:
        names = archive.namelist()
        forbidden = [
            n
            for n in names
            if any(
                part in EXCLUDED_PARTS or part.startswith(".venv")
                for part in Path(n).parts
            )
        ]
        if forbidden:
            raise SystemExit(f"El ZIP incluye rutas excluidas: {forbidden[:5]}")
        required = [
            "backend/models/irca-lineal-v1/pipeline.joblib",
            "backend/data/Calidad_del_Agua_para_Consumo_Humano_en_Colombia_20261009.csv",
            "test_files/expected_results.json",
            "docs/Documento_Tecnico.pdf",
        ]
        missing = [
            name for name in required if not any(n.endswith(name) for n in names)
        ]
        if missing:
            raise SystemExit(f"Faltan entregables requeridos: {missing}")


if __name__ == "__main__":
    main()
