"""Ejecuta escenarios mediante FastAPI TestClient y guarda reportes calculados."""

from __future__ import annotations

import json
import shutil
import sys
from pathlib import Path

from fastapi.testclient import TestClient

ROOT = Path(__file__).resolve().parents[1]
BACKEND = ROOT / "backend"
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(BACKEND))
from app.config import DATA_DIR, MODEL_DIR  # noqa: E402
from app.main import app  # noqa: E402
from app.reports.generators import report_bytes  # noqa: E402


def main():
    from scripts.generate_test_files import main as generate

    generate()
    expected = json.loads(
        (ROOT / "test_files" / "expected_results.json").read_text(encoding="utf-8")
    )
    evidence = ROOT / "docs" / "evidencias"
    evidence.mkdir(parents=True, exist_ok=True)
    registry_path = MODEL_DIR / "registry.json"
    schema_path = BACKEND / "metadata" / "schema.json"
    registry_before = registry_path.read_bytes()
    schema_before = schema_path.read_bytes()
    models_before = {p.name for p in MODEL_DIR.iterdir() if p.is_dir()}
    data_versions = DATA_DIR / "training" / "versions"
    versions_before = (
        {p.name for p in data_versions.glob("*.csv")}
        if data_versions.exists()
        else set()
    )
    candidate_dir = DATA_DIR / "training" / "candidates"
    candidates_before = (
        {p.name: p.read_bytes() for p in candidate_dir.glob("*.csv")}
        if candidate_dir.exists()
        else {}
    )
    runs_dir = BACKEND / "storage" / "runs"
    runs_before = {p.name for p in runs_dir.iterdir() if p.is_dir()}
    uploads_dir = BACKEND / "storage" / "uploads"
    uploads_before = {p.name for p in uploads_dir.iterdir() if p.is_file()}
    rows = []
    try:
        with TestClient(app) as client:
            scenario_names = [
                name
                for name in expected
                if name != "08_nuevos_datos_etiquetados_2025.csv"
            ]
            if "08_nuevos_datos_etiquetados_2025.csv" in expected:
                scenario_names.append("08_nuevos_datos_etiquetados_2025.csv")
            for name in scenario_names:
                info = expected[name]
                path = ROOT / "test_files" / name
                if not path.exists():
                    continue
                payload = path.read_bytes()
                response = client.post(
                    "/api/validate",
                    files={"file": (name, payload, "application/octet-stream")},
                )
                actual = response.json().get("validation", {})
                rows.append(
                    {
                        "archivo": name,
                        "esperado": info["expected_status"],
                        "obtenido": actual.get("status", "error"),
                        "códigos": ", ".join(
                            sorted({x["code"] for x in actual.get("findings", [])})
                        ),
                    }
                )
                run_id = response.json().get("run_id")
                if run_id:
                    for kind, formats in (
                        ("compatibility", ["pdf", "json"]),
                        ("eda", ["pdf", "json"]),
                    ):
                        for fmt in formats:
                            report = client.get(
                                f"/api/runs/{run_id}/reports/{kind}?format={fmt}"
                            )
                            if report.status_code == 200:
                                (
                                    evidence / f"{Path(name).stem}_{kind}.{fmt}"
                                ).write_bytes(report.content)
                    if actual.get("status") != "incompatible":
                        prediction = client.post(
                            "/api/predict", data={"run_id": run_id}
                        )
                        if prediction.status_code == 200:
                            for fmt in ("pdf", "csv", "xlsx"):
                                report = client.get(
                                    f"/api/runs/{run_id}/reports/predictions?format={fmt}"
                                )
                                if report.status_code == 200:
                                    (
                                        evidence
                                        / f"{Path(name).stem}_predictions.{fmt}"
                                    ).write_bytes(report.content)
                if name == "08b_reentrenamiento_claves_repetidas.csv":
                    rejected = client.post(
                        "/api/model/retrain",
                        files={"file": (name, payload, "text/csv")},
                    )
                    retrain_result = rejected.json()
                    rows[-1]["obtenido"] = retrain_result.get("status", "incompatible")
                    retrain_validation = retrain_result.get("validation", {})
                    retrain_codes = {
                        item["code"] for item in retrain_validation.get("findings", [])
                    }
                    rows[-1]["códigos"] = ", ".join(sorted(retrain_codes))
                if name == "08_nuevos_datos_etiquetados_2025.csv":
                    candidate = client.post(
                        "/api/model/retrain",
                        files={"file": (name, payload, "text/csv")},
                    )
                    data = candidate.json()
                    if candidate.status_code == 200 and data.get("candidate"):
                        (evidence / "actualizacion_modelo.json").write_text(
                            json.dumps(data["candidate"], ensure_ascii=False, indent=2),
                            encoding="utf-8",
                        )
                        pdf, _, _ = report_bytes("update", "pdf", data["candidate"])
                        (evidence / "actualizacion_modelo.pdf").write_bytes(pdf)
                        rows[-1]["obtenido"] = "candidate"
                    else:
                        rows[-1]["obtenido"] = data.get("validation", {}).get(
                            "status", candidate.status_code
                        )
            (evidence / "resultados_pruebas.md").write_text(
                "# Resultados esperados y obtenidos\n\n| Archivo | Esperado | Obtenido | Códigos observados |\n|---|---|---|---|\n"
                + "\n".join(
                    f"| {r['archivo']} | {r['esperado']} | {r['obtenido']} | {r['códigos']} |"
                    for r in rows
                )
                + "\n",
                encoding="utf-8",
            )
    finally:
        registry_path.write_bytes(registry_before)
        schema_path.write_bytes(schema_before)
        for path in MODEL_DIR.iterdir():
            if path.is_dir() and path.name not in models_before:
                shutil.rmtree(path)
        if data_versions.exists():
            for path in data_versions.glob("*.csv"):
                if path.name not in versions_before:
                    path.unlink()
        for path in candidate_dir.glob("*.csv"):
            if path.name not in candidates_before:
                path.unlink()
        for name, content in candidates_before.items():
            (candidate_dir / name).write_bytes(content)
        for path in runs_dir.iterdir():
            if path.is_dir() and path.name not in runs_before:
                shutil.rmtree(path)
        for path in uploads_dir.iterdir():
            if path.is_file() and path.name not in uploads_before:
                path.unlink()
    print(f"Evidencias guardadas en {evidence}; escenarios ejecutados: {len(rows)}")


if __name__ == "__main__":
    main()
