"""Genera archivos deterministas para probar validación, EDA y versionamiento."""

from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
BACKEND = ROOT / "backend"
sys.path.insert(0, str(BACKEND))
from app.validation.validator import validate_frame  # noqa: E402

OUT = ROOT / "test_files"
SOURCE = (
    BACKEND / "data" / "Calidad_del_Agua_para_Consumo_Humano_en_Colombia_20261009.csv"
)


def risk(value):
    if value <= 5:
        return "Sin riesgo"
    if value <= 14:
        return "Riesgo bajo"
    if value <= 35:
        return "Riesgo medio"
    if value <= 80:
        return "Riesgo alto"
    return "Inviable sanitariamente"


def main():
    OUT.mkdir(exist_ok=True)
    real = pd.read_csv(SOURCE, dtype=str, keep_default_na=False, encoding="utf-8-sig")
    recent = (
        real[real["Año"].astype(str).str.replace(",", "", regex=False).eq("2024")]
        .head(200)
        .copy()
    )
    prediction_cols = [
        "DepartamentoCodigo",
        "Departamento",
        "MunicipioCodigo",
        "Municipio",
        "Año",
        "IRCA",
    ]
    base = recent[prediction_cols].copy()
    cases = {}

    def save(name, frame, desc):
        path = OUT / name
        frame.to_csv(path, index=False, encoding="utf-8-sig")
        result = validate_frame(frame)
        cases[name] = {
            "description": desc,
            "expected_status": result["status"],
            "expected_codes": sorted({f["code"] for f in result["findings"]}),
            "rows": len(frame),
        }
        return path

    save(
        "01_compatible.csv",
        base,
        "Muestra real de 200 registros del año 2024; permite generar pronósticos para 2025.",
    )
    save(
        "02_falta_columna_irca.csv",
        base.drop(columns=["IRCA"]),
        "Muestra compatible sin la columna obligatoria IRCA; debe bloquear predicción.",
    )
    bad = base.copy()
    bad.loc[bad.index[:5], "IRCA"] = "alto"
    bad.loc[bad.index[:3], "Año"] = "veinte"
    save(
        "03_tipos_incompatibles.csv",
        bad,
        "Muestra real con textos no convertibles en IRCA y Año.",
    )
    nulls = base.copy()
    nulls.loc[nulls.index[:16], "IRCA"] = ["", "ND"] * 8
    save("04_nulos_irca.csv", nulls, "Muestra con 8 % de IRCA vacío o ND.")
    category = base.copy()
    category["Nivel de riesgo"] = recent["Nivel de riesgo"].to_list()
    category.loc[category.index[:5], "Nivel de riesgo"] = "Riesgo crítico"
    category.loc[category.index[0], "DepartamentoCodigo"] = "999"
    category.loc[category.index[0], "MunicipioCodigo"] = "99999"
    category.loc[category.index[0], "Municipio"] = "Municipio demostrativo"
    save(
        "05_categoria_desconocida.csv",
        category,
        "Incluye categoría de riesgo y código de departamento no observados.",
    )
    extras = base.copy()
    extras["Observaciones"] = "Dato administrativo"
    extras["Region_Sistema"] = "Norte"
    extras["ID_Interno"] = range(1, len(extras) + 1)
    save(
        "06_columnas_adicionales.csv",
        extras,
        "Incluye columnas adicionales que el modelo no utiliza.",
    )
    rng = np.random.default_rng(42)
    n = 160
    lab = pd.DataFrame(
        {
            "fecha_muestreo": pd.date_range("2024-01-01", periods=n, freq="D").astype(
                str
            ),
            "punto_muestreo": [f"punto-{i % 12:02d}" for i in range(n)],
            "turbidez_NTU": rng.normal(3, 1, n).clip(0, None),
            "ph": rng.normal(7, 0.7, n),
            "cloro_residual_mgL": rng.normal(0.6, 0.18, n).clip(0, None),
            "analista": [f"analista-{i % 5}" for i in range(n)],
        }
    )
    lab.loc[lab.index[:8], "ph"] = np.nan
    lab.loc[lab.index[-1], "turbidez_NTU"] = 45
    lab.loc[lab.index[-2]] = lab.loc[lab.index[-3]]
    save(
        "07_solo_eda_muestras_laboratorio.csv",
        lab,
        "Datos sintéticos de demostración de laboratorio: análisis EDA, sin esquema de predicción.",
    )
    outside = base.copy()
    outside.loc[outside.index[0], "IRCA"] = "187.4"
    outside.loc[outside.index[1], "IRCA"] = "-3"
    save(
        "07b_irca_fuera_de_rango.csv",
        outside,
        "Muestra real con dos valores de IRCA fuera del rango válido.",
    )
    # Excel idéntico a la muestra compatible.
    base.to_excel(OUT / "09_compatible.xlsx", index=False)
    cases["09_compatible.xlsx"] = {
        "description": "Libro Excel equivalente al escenario compatible para validar soporte XLSX.",
        "expected_status": "compatible",
        "expected_codes": [],
        "rows": len(base),
    }
    # Datos sintéticos etiquetados para 2025; conservan las columnas del dataset real.
    all_2024 = real[
        real["Año"].astype(str).str.replace(",", "", regex=False).eq("2024")
    ].copy()
    rng = np.random.default_rng(42)
    irca = pd.to_numeric(all_2024["IRCA"], errors="coerce").fillna(0).to_numpy(float)
    future = np.clip(0.8 * irca + 3 + rng.normal(0, 6, len(irca)), 0, 100)
    new = all_2024.copy()
    new["Año"] = "2,025"
    new["IRCA"] = [f"{x:.1f}" for x in future]
    new["Nivel de riesgo"] = [risk(x) for x in future]
    for metric, level in (
        ("IRCAurbano", "Nivel de riesgo urbano"),
        ("IRCArural", "Nivel de riesgo rural"),
    ):
        values = pd.to_numeric(all_2024[metric].replace("ND", np.nan), errors="coerce")
        generated = np.clip(
            0.8 * values.fillna(0).to_numpy(float) + 3 + rng.normal(0, 6, len(values)),
            0,
            100,
        )
        new[metric] = [
            "ND" if pd.isna(v) else f"{g:.1f}" for v, g in zip(values, generated)
        ]
        new[level] = [
            "ND" if str(v) == "ND" else risk(float(g))
            for v, g in zip(all_2024[metric], generated)
        ]
    new.to_csv(
        OUT / "08_nuevos_datos_etiquetados_2025.csv", index=False, encoding="utf-8-sig"
    )
    cases["08_nuevos_datos_etiquetados_2025.csv"] = {
        "description": "Filas sintéticas de demostración para 2025, etiquetadas y basadas en registros reales de 2024.",
        "expected_status": "candidate",
        "expected_codes": [],
        "rows": len(new),
        "synthetic": True,
        "minimum_new_pairs": 30,
    }
    repeated = all_2024.head(60).copy()
    repeated.to_csv(
        OUT / "08b_reentrenamiento_claves_repetidas.csv",
        index=False,
        encoding="utf-8-sig",
    )
    cases["08b_reentrenamiento_claves_repetidas.csv"] = {
        "description": "Claves del año 2024 ya incluidas en entrenamiento; debe rechazar la actualización.",
        "expected_status": "incompatible",
        "expected_codes": ["E_KEY_ALREADY_IN_TRAINING"],
        "rows": len(repeated),
    }
    (OUT / "expected_results.json").write_text(
        json.dumps(cases, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(
        f"Archivos creados: {len([p for p in OUT.iterdir() if p.suffix in {'.csv', '.xlsx'}])}"
    )
    print(f"Filas para actualización 2025: {len(new)}")


if __name__ == "__main__":
    main()
