"""Descarga y normaliza los indicadores PDA 2020 publicados por Aguas del Chocó.

Los campos de cobertura, continuidad, calidad declarada, infraestructura y PTAR
se conservan como aparecen en la fuente. Este archivo no reemplaza el IRCA SIVICAP.
"""

from __future__ import annotations

import csv
import json
from datetime import date
from html.parser import HTMLParser
from pathlib import Path
from urllib.request import Request, urlopen

PROJECT_DIR = Path(__file__).resolve().parents[1]
OUTPUT_DIR = PROJECT_DIR / "backend" / "data" / "contextual"
SOURCE_URL = "https://aguasdelchoco.gov.co/indicadores-pda/"
SOURCE_YEAR = 2020

FIELDS = [
    "departamento",
    "municipio",
    "anio_reporte",
    "prestador",
    "tipo_empresa",
    "servicios_prestados",
    "dato_acueducto_fuente",
    "dato_alcantarillado_fuente",
    "dato_aseo_fuente",
    "cobertura_redes_reportada",
    "cobertura_servicio_reportada",
    "continuidad_reportada",
    "calidad_agua_reportada",
    "irca_reportado",
    "estado_infraestructura_reportado",
    "ptar_reportada",
]


class TableParser(HTMLParser):
    def __init__(self) -> None:
        super().__init__()
        self.depth = 0
        self.tables: list[list[list[str]]] = []
        self.rows: list[list[str]] = []
        self.row: list[str] | None = None
        self.cell_tag: str | None = None
        self.cell_text: list[str] = []

    def handle_starttag(self, tag: str, attrs) -> None:
        if tag == "table":
            if self.depth == 0:
                self.rows = []
            self.depth += 1
        elif self.depth == 1 and tag == "tr":
            self.row = []
        elif self.depth == 1 and tag in {"td", "th"}:
            self.cell_tag = tag
            self.cell_text = []
        elif self.depth == 1 and tag in {"br", "p"} and self.cell_tag:
            self.cell_text.append(" ")

    def handle_data(self, data: str) -> None:
        if self.depth == 1 and self.cell_tag:
            self.cell_text.append(data)

    def handle_endtag(self, tag: str) -> None:
        if self.depth == 1 and tag in {"td", "th"} and self.cell_tag:
            value = " ".join("".join(self.cell_text).split())
            if self.row is not None:
                self.row.append(value)
            self.cell_tag = None
            self.cell_text = []
        elif self.depth == 1 and tag == "tr" and self.row is not None:
            if self.row:
                self.rows.append(self.row)
            self.row = None
        elif tag == "table" and self.depth:
            self.depth -= 1
            if self.depth == 0:
                self.tables.append(self.rows)


def fetch_table() -> list[list[str]]:
    request = Request(SOURCE_URL, headers={"User-Agent": "Mozilla/5.0"})
    with urlopen(request, timeout=45) as response:
        html = response.read().decode("utf-8", errors="replace")
    parser = TableParser()
    parser.feed(html)
    for table in parser.tables:
        if table and any(cell.strip().upper() == "MUNICIPIOS" for cell in table[0]):
            return table
    raise RuntimeError("No se encontró la tabla de municipios en la fuente de Aguas del Chocó.")


def main() -> None:
    table = fetch_table()
    headers = table[0]
    if len(headers) != 38 or any(len(row) != len(headers) for row in table[1:]):
        raise RuntimeError("La estructura de la tabla cambió; revise la fuente antes de importarla.")
    index = {header.strip().casefold(): pos for pos, header in enumerate(headers)}

    def value(row: list[str], key: str) -> str:
        return row[index[key.casefold()]].strip()

    records = []
    for row in table[1:]:
        municipality = value(row, "MUNICIPIOS")
        if not municipality:
            continue
        records.append(
            {
                "departamento": "Chocó",
                "municipio": municipality,
                "anio_reporte": SOURCE_YEAR,
                "prestador": value(row, "EMPRESA PRESTADORA"),
                "tipo_empresa": value(row, "TIPO DE EMPRESA"),
                "servicios_prestados": value(row, "SERVICIOS PRESTADOS"),
                "dato_acueducto_fuente": value(row, "Acueducto"),
                "dato_alcantarillado_fuente": value(row, "Alcantarillado"),
                "dato_aseo_fuente": value(row, "Aseo"),
                "cobertura_redes_reportada": value(row, "Cobertura en Redes"),
                "cobertura_servicio_reportada": value(row, "Cobertura en Servicio"),
                "continuidad_reportada": value(row, "Continuidad"),
                "calidad_agua_reportada": value(row, "Calidad del Agua"),
                "irca_reportado": value(row, "IRCA"),
                "estado_infraestructura_reportado": value(row, "Estado de la Infraestructura"),
                "ptar_reportada": value(row, "PTAR"),
            }
        )

    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    csv_path = OUTPUT_DIR / "aguas_del_choco_indicadores_pda_2020.csv"
    with csv_path.open("w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=FIELDS)
        writer.writeheader()
        writer.writerows(records)
    metadata = {
        "nombre": "Indicadores PDA 2020 de Aguas del Chocó",
        "entidad": "Aguas del Chocó S.A. E.S.P.",
        "url_fuente": SOURCE_URL,
        "fecha_consulta": date.today().isoformat(),
        "anio_indicador": SOURCE_YEAR,
        "filas": len(records),
        "columnas": FIELDS,
        "notas": [
            "Los indicadores de contexto corresponden a la ficha publicada como Indicadores PDA 2020.",
            "Los valores de continuidad, calidad e infraestructura se conservan como texto reportado por la fuente.",
            "El campo IRCA de esta tabla se incluye como aparece; las celdas vacías no se imputan.",
            "Los datos de años 2015 a 2020 que aparecen en otras columnas de la página no se incluyen porque su encabezado compuesto no permite atribuirles una variable inequívoca.",
            "La comparación con SIVICAP se limita al año 2020; es exploratoria y no prueba causalidad.",
        ],
    }
    (OUTPUT_DIR / "fuente_aguas_del_choco.json").write_text(
        json.dumps(metadata, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    print(f"CSV: {csv_path}")
    print(f"Registros: {len(records)}")
    print(f"Campos analíticos: {len(FIELDS)}")


if __name__ == "__main__":
    main()
