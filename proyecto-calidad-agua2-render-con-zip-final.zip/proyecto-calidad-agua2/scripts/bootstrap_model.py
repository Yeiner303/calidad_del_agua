"""Entrena y registra el modelo base a partir del CSV oficial."""

from __future__ import annotations

import hashlib
import json
import sys
from datetime import UTC, datetime
from pathlib import Path
from zoneinfo import ZoneInfo

import joblib
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
BACKEND = ROOT / "backend"
sys.path.insert(0, str(BACKEND))
from app.config import MODEL_DIR  # noqa: E402
from app.pipeline.training import train_and_evaluate  # noqa: E402


def atomic_json(path: Path, payload: dict) -> None:
    temp = path.with_suffix(path.suffix + ".tmp")
    temp.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2, allow_nan=False),
        encoding="utf-8",
    )
    temp.replace(path)


def main() -> None:
    source = (
        BACKEND
        / "data"
        / "Calidad_del_Agua_para_Consumo_Humano_en_Colombia_20261009.csv"
    )
    raw = source.read_bytes()
    frame = pd.read_csv(source, dtype=str, keep_default_na=False, encoding="utf-8-sig")
    trained = train_and_evaluate(frame)
    model_id = "irca-lineal-v1"
    target_dir = MODEL_DIR / model_id
    target_dir.mkdir(parents=True, exist_ok=True)
    artifact = target_dir / "pipeline.joblib"
    joblib.dump(trained["model"], artifact)
    now = datetime.now(UTC)
    metadata = {
        "id": model_id,
        "status": "active",
        "trained_at": now.isoformat(),
        "trained_at_local": now.astimezone(ZoneInfo("America/Bogota")).isoformat(),
        "source_rows": len(frame),
        "training_pairs": len(trained["pairs"]),
        "features": ["IRCA_t", "Año_desde_2007"],
        "algorithm": "Regresión lineal ordinaria (mínimos cuadrados)",
        "model": trained["model"].to_metadata(),
        "evaluation": trained["evaluation"],
        "dataset_ref": {
            "filename": source.name,
            "sha256": hashlib.sha256(raw).hexdigest(),
            "storage_path": f"versions/{model_id}.csv",
        },
        "artifact_path": f"{model_id}/pipeline.joblib",
        "parent_version": None,
        "decisions": [],
    }
    atomic_json(target_dir / "metadata.json", metadata)
    registry = {
        "active_version": model_id,
        "versions": [metadata],
        "pending_candidate": None,
    }
    atomic_json(MODEL_DIR / "registry.json", registry)
    schema_path = BACKEND / "metadata" / "schema.json"
    schema = json.loads(schema_path.read_text(encoding="utf-8"))
    schema["dataset"]["sha256"] = metadata["dataset_ref"]["sha256"]
    schema["active_model"] = {
        "id": model_id,
        "trained_at": metadata["trained_at"],
        "primary_metric": "mae",
        "primary_metric_value": metadata["evaluation"]["metrics"]["mae"],
    }
    atomic_json(schema_path, schema)
    active_copy = BACKEND / "data" / "training" / "active.csv"
    active_copy.parent.mkdir(parents=True, exist_ok=True)
    active_copy.write_bytes(raw)
    print(f"Transiciones consecutivas: {len(trained['pairs'])}")
    print(f"Pares de entrenamiento: {trained['evaluation']['training_pairs']}")
    print(f"Pares de prueba: {trained['evaluation']['test_pairs']}")
    print(
        f"Años objetivo de prueba: {trained['evaluation']['test_start_year']} a {trained['evaluation']['latest_target_year']}"
    )
    for key, label in (("mae", "MAE"), ("rmse", "RMSE"), ("r2", "R2")):
        print(f"{label} del modelo: {trained['evaluation']['metrics'][key]:.4f}")
    print(
        f"MAE de referencia (persistencia): {trained['evaluation']['persistence_baseline']['mae']:.4f}"
    )
    print(
        f"RMSE de referencia (persistencia): {trained['evaluation']['persistence_baseline']['rmse']:.4f}"
    )
    print(
        "Coeficientes del artefacto final:",
        [round(x, 8) for x in trained["model"].to_metadata()["coefficients"]],
    )
    print(f"Artefacto: {artifact}")


if __name__ == "__main__":
    main()
