# Desplegar en Render desde este ZIP

Sube este archivo ZIP a la raíz de un repositorio vacío de GitHub. El nombre del archivo debe conservarse como `proyecto-calidad-agua2-render-con-zip.zip`. Render descomprimirá el proyecto al iniciar cada compilación.

## API (Web Service)

- Runtime: Python 3
- Root Directory: vacío
- Environment variable: `PYTHON_VERSION=3.12.11`
- Build Command: `unzip -oq proyecto-calidad-agua2-render-con-zip.zip -d . && pip install -r proyecto-calidad-agua2/backend/requirements.txt`
- Start Command: `uvicorn app.main:app --app-dir proyecto-calidad-agua2/backend --host 0.0.0.0 --port $PORT`

Después del primer deploy, copia la URL de la API.

## Sitio React (Static Site)

- Root Directory: vacío
- Build Command: `unzip -oq proyecto-calidad-agua2-render-con-zip.zip -d . && cd proyecto-calidad-agua2/frontend && npm ci && npm run build`
- Publish Directory: `proyecto-calidad-agua2/frontend/dist`
- Environment variable: `VITE_API_URL=https://<URL-de-la-API>` (sin `/api` al final)
- Rewrite: `/*` → `/index.html`

Después del primer deploy del sitio, agrega en la API `FRONTEND_ORIGIN=https://<URL-del-sitio>` y redepliega la API.
